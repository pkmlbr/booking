"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import { Card } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Star, MapPin, ChevronLeft, ChevronRight, Wifi, Car, Coffee, Check } from "lucide-react"
import { Skeleton } from "@/components/ui/skeleton"
import ErrorWithRetry from "@/components/error-with-retry"
import OptimizedImage from "@/components/optimized-image"

interface HotelListProps {
  location?: string
  checkIn?: string
  checkOut?: string
  adults?: number
  children?: number
  page?: number
}

interface Hotel {
  id: string
  name: string
  city: string
  state: string
  starRating: number | null
  minPrice: number | null
  isFeatured: boolean
  description?: string
  rating?: number
  reviewCount?: number
  facilities?: string[]
  images: {
    id: string
    imageUrl: string
    isPrimary: boolean
  }[]
}

interface PaginationData {
  total: number
  page: number
  limit: number
  pages: number
}

export default function HotelList({ location, checkIn, checkOut, adults = 2, children = 0, page = 1 }: HotelListProps) {
  const router = useRouter()
  const [hotels, setHotels] = useState<Hotel[]>([])
  const [pagination, setPagination] = useState<PaginationData>({
    total: 0,
    page: 1,
    limit: 10,
    pages: 1,
  })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchHotels = async () => {
    setLoading(true)
    setError(null)

    try {
      // Construir URL com parâmetros
      const params = new URLSearchParams()
      if (location) params.append("location", location)
      if (checkIn) params.append("checkIn", checkIn)
      if (checkOut) params.append("checkOut", checkOut)
      if (adults) params.append("adults", adults.toString())
      if (children) params.append("children", children.toString())
      if (page) params.append("page", page.toString())

      // Buscar hotéis da API
      const response = await fetch(`/api/hotels?${params.toString()}`, {
        cache: "no-store", // Importante: não usar cache para sempre obter os dados mais recentes
      })

      if (!response.ok) {
        throw new Error("Falha ao buscar hotéis")
      }

      const data = await response.json()

      // Adicionar dados fictícios para demonstração
      const enhancedHotels = data.hotels.map((hotel: Hotel) => ({
        ...hotel,
        description:
          hotel.description || "Este hotel oferece acomodações confortáveis em uma localização privilegiada.",
        rating: hotel.rating || Math.floor(Math.random() * 3) + 7, // Rating entre 7 e 9.9
        reviewCount: hotel.reviewCount || Math.floor(Math.random() * 1000) + 100,
        facilities: hotel.facilities || ["Wi-Fi", "Estacionamento", "Café da manhã", "Ar-condicionado"],
      }))

      setHotels(enhancedHotels)
      setPagination(data.pagination)
    } catch (err) {
      console.error("Erro ao buscar hotéis:", err)
      setError("Não foi possível carregar os hotéis. Tente novamente.")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchHotels()
  }, [location, checkIn, checkOut, adults, children, page])

  const handlePageChange = (newPage: number) => {
    // Atualizar a URL com a nova página
    const params = new URLSearchParams(window.location.search)
    params.set("page", newPage.toString())
    router.push(`/hotels?${params.toString()}`)
  }

  const getRatingLabel = (rating: number) => {
    if (rating >= 9.0) return "Excelente"
    if (rating >= 8.0) return "Muito bom"
    if (rating >= 7.0) return "Bom"
    if (rating >= 6.0) return "Agradável"
    return "Avaliado"
  }

  const getRatingColor = (rating: number) => {
    if (rating >= 9.0) return "bg-[#004cb8]"
    if (rating >= 8.0) return "bg-[#0a6a4a]"
    if (rating >= 7.0) return "bg-[#6a8a00]"
    if (rating >= 6.0) return "bg-[#c26b00]"
    return "bg-[#767676]"
  }

  if (loading) {
    return (
      <div className="space-y-4">
        {[...Array(5)].map((_, index) => (
          <Card key={index} className="overflow-hidden">
            <div className="flex flex-col md:flex-row">
              <Skeleton className="h-48 w-full md:w-64" />
              <div className="p-4 space-y-2 flex-1">
                <Skeleton className="h-6 w-3/4" />
                <Skeleton className="h-4 w-1/2" />
                <div className="flex items-center">
                  <Skeleton className="h-4 w-24" />
                </div>
                <Skeleton className="h-6 w-1/3" />
              </div>
            </div>
          </Card>
        ))}
      </div>
    )
  }

  if (error) {
    return <ErrorWithRetry message={error} onRetry={fetchHotels} />
  }

  if (hotels.length === 0) {
    return (
      <div className="text-center py-12">
        <h2 className="text-2xl font-semibold mb-4">Nenhum hotel encontrado</h2>
        <p className="text-gray-500 dark:text-gray-400 mb-6">
          Tente ajustar seus filtros ou buscar por outra localização.
        </p>
        <Button onClick={() => router.push("/hotels")}>Ver todos os hotéis</Button>
      </div>
    )
  }

  return (
    <div className="space-y-8">
      <div className="flex justify-between items-center">
        <h2 className="text-xl font-semibold">
          {pagination.total} {pagination.total === 1 ? "propriedade encontrada" : "propriedades encontradas"}
          {location ? ` em "${location}"` : ""}
        </h2>
      </div>

      <div className="space-y-4">
        {hotels.map((hotel) => (
          <Link href={`/hotels/${hotel.id}`} key={hotel.id}>
            <Card className="overflow-hidden hover:shadow-md transition-shadow duration-300 flex flex-col md:flex-row">
              <div className="relative h-48 md:w-64 md:h-auto">
                <OptimizedImage
                  src={
                    hotel.images[0]?.imageUrl ||
                    `/placeholder.svg?height=200&width=300&query=hotel+em+${encodeURIComponent(hotel.city)}`
                  }
                  alt={hotel.name}
                  fill
                  className="object-cover"
                />
                {hotel.isFeatured && <Badge className="absolute top-2 left-2 bg-booking-blue">Destaque</Badge>}
              </div>

              <div className="p-4 flex-1 flex flex-col md:flex-row">
                <div className="flex-1">
                  <div className="flex justify-between">
                    <h3 className="font-bold text-lg text-booking-blue-light">{hotel.name}</h3>
                    {hotel.starRating && (
                      <div className="flex">
                        {Array.from({ length: Math.floor(hotel.starRating) }).map((_, i) => (
                          <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                        ))}
                      </div>
                    )}
                  </div>

                  <p className="text-sm text-gray-600 mb-2 flex items-center">
                    <MapPin className="h-4 w-4 mr-1" />
                    {hotel.city}, {hotel.state}
                  </p>

                  <p className="text-sm mb-3 line-clamp-2">{hotel.description}</p>

                  <div className="flex flex-wrap gap-2 mb-3">
                    {hotel.facilities?.slice(0, 4).map((facility, index) => (
                      <span key={index} className="text-xs bg-gray-100 px-2 py-1 rounded flex items-center">
                        {facility === "Wi-Fi" && <Wifi className="h-3 w-3 mr-1" />}
                        {facility === "Estacionamento" && <Car className="h-3 w-3 mr-1" />}
                        {facility === "Café da manhã" && <Coffee className="h-3 w-3 mr-1" />}
                        {facility === "Ar-condicionado" && <Check className="h-3 w-3 mr-1" />}
                        {facility}
                      </span>
                    ))}
                  </div>
                </div>

                <div className="md:w-48 flex flex-col justify-between md:border-l md:pl-4">
                  <div className="flex justify-end items-center mb-2">
                    <div className="flex flex-col items-end">
                      <div className="flex items-center">
                        <span className="font-medium mr-2">{getRatingLabel(hotel.rating || 0)}</span>
                        <div className={`${getRatingColor(hotel.rating || 0)} text-white font-bold px-2 py-1 rounded`}>
                          {hotel.rating?.toFixed(1)}
                        </div>
                      </div>
                      <span className="text-xs text-gray-500">{hotel.reviewCount} avaliações</span>
                    </div>
                  </div>

                  <div className="text-right mt-4">
                    {hotel.minPrice ? (
                      <>
                        <p className="text-sm text-gray-500">Preço por noite a partir de</p>
                        <p className="font-bold text-xl text-booking-blue">R$ {hotel.minPrice.toFixed(2)}</p>
                        <Button className="mt-2 bg-booking-blue">Ver disponibilidade</Button>
                      </>
                    ) : (
                      <>
                        <p className="text-sm text-gray-500">Preço não disponível</p>
                        <Button className="mt-2 bg-booking-blue">Ver detalhes</Button>
                      </>
                    )}
                  </div>
                </div>
              </div>
            </Card>
          </Link>
        ))}
      </div>

      {/* Paginação */}
      {pagination.pages > 1 && (
        <div className="flex justify-center mt-8">
          <div className="flex items-center space-x-2">
            <Button
              variant="outline"
              size="icon"
              onClick={() => handlePageChange(pagination.page - 1)}
              disabled={pagination.page === 1}
            >
              <ChevronLeft className="h-4 w-4" />
            </Button>

            {[...Array(pagination.pages)].map((_, i) => {
              const pageNumber = i + 1
              // Mostrar apenas páginas próximas à atual
              if (
                pageNumber === 1 ||
                pageNumber === pagination.pages ||
                (pageNumber >= pagination.page - 1 && pageNumber <= pagination.page + 1)
              ) {
                return (
                  <Button
                    key={pageNumber}
                    variant={pageNumber === pagination.page ? "default" : "outline"}
                    onClick={() => handlePageChange(pageNumber)}
                    className={`w-10 h-10 ${pageNumber === pagination.page ? "bg-booking-blue" : ""}`}
                  >
                    {pageNumber}
                  </Button>
                )
              }

              // Mostrar reticências para páginas omitidas
              if (pageNumber === 2 || pageNumber === pagination.pages - 1) {
                return (
                  <span key={`ellipsis-${pageNumber}`} className="px-2">
                    ...
                  </span>
                )
              }

              return null
            })}

            <Button
              variant="outline"
              size="icon"
              onClick={() => handlePageChange(pagination.page + 1)}
              disabled={pagination.page === pagination.pages}
            >
              <ChevronRight className="h-4 w-4" />
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
