"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import Image from "next/image"
import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Star } from "lucide-react"
import { Skeleton } from "@/components/ui/skeleton"

type Hotel = {
  id: string
  name: string
  city: string
  state: string
  starRating: number
  minPrice: number
  isFeatured: boolean
  images: {
    id: string
    imageUrl: string
    isPrimary: boolean
  }[]
}

export default function FeaturedHotels() {
  const [hotels, setHotels] = useState<Hotel[]>([])
  const [loading, setLoading] = useState(true)

  useEffect(() => {
    const fetchHotels = async () => {
      try {
        // Em um ambiente real, isso seria uma chamada de API
        // const response = await fetch('/api/hotels/featured')
        // const data = await response.json()

        // Dados simulados para demonstração
        const mockHotels = [
          {
            id: "1",
            name: "Grand Hotel Rio",
            city: "Rio de Janeiro",
            state: "RJ",
            starRating: 4.5,
            minPrice: 450,
            isFeatured: true,
            images: [
              {
                id: "101",
                imageUrl: "/beach-resort-rio.png",
                isPrimary: true,
              },
            ],
          },
          {
            id: "2",
            name: "Pousada Gramado",
            city: "Gramado",
            state: "RS",
            starRating: 4.0,
            minPrice: 320,
            isFeatured: true,
            images: [
              {
                id: "102",
                imageUrl: "/mountain-lodge-gramado.png",
                isPrimary: true,
              },
            ],
          },
          {
            id: "3",
            name: "Resort Bahia",
            city: "Salvador",
            state: "BA",
            starRating: 5.0,
            minPrice: 580,
            isFeatured: true,
            images: [
              {
                id: "103",
                imageUrl: "/bahia-beach-resort.png",
                isPrimary: true,
              },
            ],
          },
          {
            id: "4",
            name: "Hotel Colonial Paraty",
            city: "Paraty",
            state: "RJ",
            starRating: 4.2,
            minPrice: 290,
            isFeatured: true,
            images: [
              {
                id: "104",
                imageUrl: "/colonial-inn-paraty.png",
                isPrimary: true,
              },
            ],
          },
        ]

        setHotels(mockHotels)
        setLoading(false)
      } catch (error) {
        console.error("Erro ao buscar hotéis em destaque:", error)
        setLoading(false)
      }
    }

    fetchHotels()
  }, [])

  if (loading) {
    return (
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        {[...Array(4)].map((_, index) => (
          <Card key={index} className="overflow-hidden">
            <Skeleton className="h-48 w-full" />
            <CardContent className="p-4">
              <Skeleton className="h-6 w-3/4 mb-2" />
              <Skeleton className="h-4 w-1/2 mb-4" />
              <div className="flex items-center mb-2">
                <Skeleton className="h-4 w-24" />
              </div>
              <Skeleton className="h-5 w-1/3" />
            </CardContent>
          </Card>
        ))}
      </div>
    )
  }

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
      {hotels.map((hotel) => (
        <Link href={`/hotels/${hotel.id}`} key={hotel.id}>
          <Card className="overflow-hidden hover:shadow-lg transition-shadow duration-300 h-full flex flex-col">
            <div className="relative h-48">
              <Image
                src={hotel.images[0]?.imageUrl || "/placeholder.svg?height=200&width=300&query=hotel"}
                alt={hotel.name}
                fill
                className="object-cover"
              />
              {hotel.isFeatured && <Badge className="absolute top-2 right-2 bg-primary">Destaque</Badge>}
            </div>
            <CardContent className="p-4 flex-grow">
              <h3 className="font-bold text-lg mb-1 line-clamp-1">{hotel.name}</h3>
              <p className="text-gray-500 dark:text-gray-400 text-sm mb-3">
                {hotel.city}, {hotel.state}
              </p>
              <div className="flex items-center mb-2">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`h-4 w-4 ${
                      i < Math.floor(hotel.starRating)
                        ? "text-yellow-400 fill-yellow-400"
                        : i < hotel.starRating
                          ? "text-yellow-400 fill-yellow-400 opacity-50"
                          : "text-gray-300"
                    }`}
                  />
                ))}
                <span className="ml-1 text-sm text-gray-600 dark:text-gray-400">{hotel.starRating.toFixed(1)}</span>
              </div>
            </CardContent>
            <CardFooter className="p-4 pt-0 border-t">
              <p className="font-bold text-lg text-primary">
                R$ {hotel.minPrice.toFixed(2)}
                <span className="text-sm font-normal text-gray-500 dark:text-gray-400"> / noite</span>
              </p>
            </CardFooter>
          </Card>
        </Link>
      ))}
    </div>
  )
}
