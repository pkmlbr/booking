"use client"

import { useState } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"

interface Destination {
  id: number
  name: string
  state: string
  image: string
  slug: string
}

export default function MobileDestinations() {
  const router = useRouter()
  const [destinations] = useState<Destination[]>([
    {
      id: 1,
      name: "Florianópolis",
      state: "SC",
      image: "/florianopolis.png",
      slug: "florianopolis",
    },
    {
      id: 2,
      name: "Águas Claras",
      state: "DF",
      image: "/aguas-claras.png",
      slug: "aguas-claras",
    },
    {
      id: 3,
      name: "Teresópolis",
      state: "RJ",
      image: "/teresopolis.png",
      slug: "teresopolis",
    },
  ])

  const handleDestinationClick = (destination: Destination) => {
    router.push(`/hotels?location=${destination.name}`)
  }

  return (
    <div className="py-4">
      <h2 className="mobile-section-title">Conheça o Brasil</h2>

      <div className="scroll-container">
        {destinations.map((destination) => (
          <div
            key={destination.id}
            className="mobile-destination-card w-24"
            onClick={() => handleDestinationClick(destination)}
          >
            <div className="relative w-20 h-20 mx-auto">
              <Image
                src={destination.image || `/placeholder.svg?height=100&width=100&query=${destination.name}`}
                alt={destination.name}
                fill
                className="object-cover rounded-md"
              />
            </div>
            <div className="text-center mt-1">
              <h3 className="text-xs font-medium">{destination.name}</h3>
              <p className="text-xs text-gray-500">{destination.state}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
