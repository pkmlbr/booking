"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { format, addDays } from "date-fns"
import { ptBR } from "date-fns/locale"
import { Users, MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger } from "@/components/ui/dialog"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"

interface BookingMobileSearchProps {
  initialLocation?: string
  initialCheckIn?: Date
  initialCheckOut?: Date
  initialAdults?: number
  initialChildren?: number
  initialRooms?: number
}

export default function BookingMobileSearch({
  initialLocation = "",
  initialCheckIn,
  initialCheckOut,
  initialAdults = 2,
  initialChildren = 0,
  initialRooms = 1,
}: BookingMobileSearchProps) {
  const router = useRouter()
  const [location, setLocation] = useState(initialLocation)
  const [checkIn, setCheckIn] = useState<Date | undefined>(initialCheckIn || new Date())
  const [checkOut, setCheckOut] = useState<Date | undefined>(initialCheckOut || addDays(new Date(), 1))
  const [adults, setAdults] = useState(initialAdults || 2)
  const [children, setChildren] = useState(initialChildren || 0)
  const [rooms, setRooms] = useState(initialRooms || 1)

  const [isLocationOpen, setIsLocationOpen] = useState(false)
  const [isDateOpen, setIsDateOpen] = useState(false)
  const [isGuestsOpen, setIsGuestsOpen] = useState(false)

  // Atualizar estados quando as props mudarem
  useEffect(() => {
    setLocation(initialLocation || "")
    setCheckIn(initialCheckIn || new Date())
    setCheckOut(initialCheckOut || addDays(new Date(), 1))
    setAdults(initialAdults || 2)
    setChildren(initialChildren || 0)
    setRooms(initialRooms || 1)
  }, [initialLocation, initialCheckIn, initialCheckOut, initialAdults, initialChildren, initialRooms])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()

    const params = new URLSearchParams()

    if (location) params.append("location", location)
    if (checkIn) params.append("checkIn", format(checkIn, "yyyy-MM-dd"))
    if (checkOut) params.append("checkOut", format(checkOut, "yyyy-MM-dd"))
    if (adults > 0) params.append("adults", adults.toString())
    if (children > 0) params.append("children", children.toString())
    if (rooms > 0) params.append("rooms", rooms.toString())

    router.push(`/hotels?${params.toString()}`)
  }

  return (
    <div className="bg-booking-blue px-4 pt-4 pb-10">
      <h1 className="text-white text-xl font-bold mb-2">Encontre sua próxima estadia</h1>
      <p className="text-white text-sm mb-4">Encontre ofertas em hotéis, casas e muito mais...</p>

      <div className="mobile-search-form">
        {/* Destino */}
        <Dialog open={isLocationOpen} onOpenChange={setIsLocationOpen}>
          <DialogTrigger asChild>
            <div className="mobile-search-input mb-3">
              <MapPin className="h-5 w-5 text-gray-400 mr-2" />
              <div className="flex-1">
                <div className="text-xs text-gray-500">Destino</div>
                <div className="text-sm font-medium truncate">{location || "Para onde você vai?"}</div>
              </div>
            </div>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Destino</DialogTitle>
            </DialogHeader>
            <div className="py-4">
              <Input
                placeholder="Para onde você vai?"
                value={location}
                onChange={(e) => setLocation(e.target.value)}
                className="mb-4"
              />
              <div className="space-y-2">
                <h3 className="text-sm font-medium">Destinos populares</h3>
                <div className="space-y-2">
                  {["Rio de Janeiro", "São Paulo", "Salvador", "Fortaleza", "Brasília"].map((city) => (
                    <div
                      key={city}
                      className="p-2 border rounded cursor-pointer hover:bg-gray-50"
                      onClick={() => {
                        setLocation(city)
                        setIsLocationOpen(false)
                      }}
                    >
                      {city}
                    </div>
                  ))}
                </div>
              </div>
            </div>
          </DialogContent>
        </Dialog>

        {/* Datas */}
        <Dialog open={isDateOpen} onOpenChange={setIsDateOpen}>
          <DialogTrigger asChild>
            <div className="mobile-search-dates mb-3">
              <div className="mobile-search-date">
                <div className="text-xs text-gray-500">Check-in</div>
                <div className="text-sm font-medium">
                  {checkIn ? format(checkIn, "EEE, dd MMM", { locale: ptBR }) : "Selecionar data"}
                </div>
              </div>
              <div className="mobile-search-date">
                <div className="text-xs text-gray-500">Check-out</div>
                <div className="text-sm font-medium">
                  {checkOut ? format(checkOut, "EEE, dd MMM", { locale: ptBR }) : "Selecionar data"}
                </div>
              </div>
            </div>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Datas</DialogTitle>
            </DialogHeader>
            <div className="py-4">
              <div className="mb-4">
                <h3 className="text-sm font-medium mb-2">Check-in</h3>
                <CalendarComponent
                  mode="single"
                  selected={checkIn}
                  onSelect={(date) => {
                    setCheckIn(date)
                    if (date && (!checkOut || date >= checkOut)) {
                      const newCheckOut = new Date(date)
                      newCheckOut.setDate(newCheckOut.getDate() + 1)
                      setCheckOut(newCheckOut)
                    }
                  }}
                  disabled={(date) => date < new Date()}
                  locale={ptBR}
                  className="rounded border"
                />
              </div>
              <div>
                <h3 className="text-sm font-medium mb-2">Check-out</h3>
                <CalendarComponent
                  mode="single"
                  selected={checkOut}
                  onSelect={(date) => setCheckOut(date)}
                  disabled={(date) => date < new Date() || (checkIn ? date <= checkIn : false)}
                  locale={ptBR}
                  className="rounded border"
                />
              </div>
              <Button className="w-full mt-4 bg-booking-blue" onClick={() => setIsDateOpen(false)}>
                Concluído
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        {/* Hóspedes */}
        <Dialog open={isGuestsOpen} onOpenChange={setIsGuestsOpen}>
          <DialogTrigger asChild>
            <div className="mobile-search-input mb-3">
              <Users className="h-5 w-5 text-gray-400 mr-2" />
              <div className="flex-1">
                <div className="text-xs text-gray-500">Hóspedes</div>
                <div className="text-sm font-medium">
                  {adults} {adults === 1 ? "adulto" : "adultos"}
                  {children > 0 ? `, ${children} ${children === 1 ? "criança" : "crianças"}` : ""}
                  {rooms > 1 ? `, ${rooms} quartos` : ""}
                </div>
              </div>
            </div>
          </DialogTrigger>
          <DialogContent className="sm:max-w-[425px]">
            <DialogHeader>
              <DialogTitle>Hóspedes e quartos</DialogTitle>
            </DialogHeader>
            <div className="py-4 space-y-4">
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Adultos</p>
                </div>
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setAdults(Math.max(1, adults - 1))}
                    disabled={adults <= 1}
                  >
                    -
                  </Button>
                  <span className="w-8 text-center">{adults}</span>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setAdults(adults + 1)}
                    disabled={adults + children >= 20}
                  >
                    +
                  </Button>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Crianças</p>
                  <p className="text-sm text-muted-foreground">0-17 anos</p>
                </div>
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setChildren(Math.max(0, children - 1))}
                    disabled={children <= 0}
                  >
                    -
                  </Button>
                  <span className="w-8 text-center">{children}</span>
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setChildren(children + 1)}
                    disabled={adults + children >= 20}
                  >
                    +
                  </Button>
                </div>
              </div>
              <div className="flex items-center justify-between">
                <div>
                  <p className="font-medium">Quartos</p>
                </div>
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    size="icon"
                    onClick={() => setRooms(Math.max(1, rooms - 1))}
                    disabled={rooms <= 1}
                  >
                    -
                  </Button>
                  <span className="w-8 text-center">{rooms}</span>
                  <Button variant="outline" size="icon" onClick={() => setRooms(rooms + 1)} disabled={rooms >= 10}>
                    +
                  </Button>
                </div>
              </div>
              <Button className="w-full mt-4 bg-booking-blue" onClick={() => setIsGuestsOpen(false)}>
                Concluído
              </Button>
            </div>
          </DialogContent>
        </Dialog>

        <Button className="mobile-search-button" onClick={handleSearch}>
          Pesquisar
        </Button>
      </div>
    </div>
  )
}
