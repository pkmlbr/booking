"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { cn } from "@/lib/utils"

interface ProgressiveImageProps {
  src: string
  lowResSrc?: string
  alt: string
  width?: number
  height?: number
  fill?: boolean
  className?: string
  priority?: boolean
  sizes?: string
}

export default function ProgressiveImage({
  src,
  lowResSrc,
  alt,
  width,
  height,
  fill = false,
  className,
  priority = false,
  sizes,
  ...props
}: ProgressiveImageProps) {
  const [isLoaded, setIsLoaded] = useState(false)
  const [currentSrc, setCurrentSrc] = useState(lowResSrc || src)

  useEffect(() => {
    // Se não houver uma versão de baixa resolução, não fazer nada
    if (!lowResSrc || lowResSrc === src) return

    // Pré-carregar a imagem de alta resolução
    const highResImage = new Image()
    highResImage.src = src

    // Quando a imagem de alta resolução estiver carregada, atualizar a fonte
    highResImage.onload = () => {
      setCurrentSrc(src)
    }
  }, [lowResSrc, src])

  return (
    <div className={cn("overflow-hidden relative", className)}>
      <Image
        src={currentSrc || "/placeholder.svg"}
        alt={alt}
        width={fill ? undefined : width}
        height={fill ? undefined : height}
        fill={fill}
        priority={priority}
        sizes={sizes}
        className={cn("transition-opacity duration-500", isLoaded ? "opacity-100" : "opacity-0", className)}
        onLoad={() => setIsLoaded(true)}
        {...props}
      />

      {!isLoaded && <div className="absolute inset-0 bg-gray-200 dark:bg-gray-800 animate-pulse" />}
    </div>
  )
}
