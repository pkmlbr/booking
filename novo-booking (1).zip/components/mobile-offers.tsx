"use client"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

interface Offer {
  id: number
  title: string
  description: string
  image: string
  link: string
  buttonText: string
  color: string
}

export default function MobileOffers() {
  const [offers] = useState<Offer[]>([
    {
      id: 1,
      title: "Viagens rápidas, seu próximo",
      description: "Encontre o destino perfeito para um fim de semana prolongado",
      image: "/weekend-getaway.png",
      link: "/hotels?purpose=weekend",
      buttonText: "Pesquisar",
      color: "bg-booking-blue",
    },
    {
      id: 2,
      title: "Ofertas para viajar de carro",
      description: "Encontre destinos próximos para viajar de carro",
      image: "/road-trip.png",
      link: "/hotels?purpose=road-trip",
      buttonText: "Explorar",
      color: "bg-booking-blue",
    },
  ])

  return (
    <div className="py-4">
      <h2 className="mobile-section-title">Ofertas</h2>

      <div className="px-4 space-y-3">
        {offers.map((offer) => (
          <div key={offer.id} className={`${offer.color} text-white p-4 rounded-lg`}>
            <h3 className="font-bold mb-1">{offer.title}</h3>
            <p className="text-sm mb-3">{offer.description}</p>
            <Link href={offer.link}>
              <Button className="bg-white text-booking-blue hover:bg-gray-100">{offer.buttonText}</Button>
            </Link>
          </div>
        ))}
      </div>
    </div>
  )
}
