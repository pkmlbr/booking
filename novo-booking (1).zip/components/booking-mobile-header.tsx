"use client"

import { useState } from "react"
import Link from "next/link"
import { useAuth } from "@/contexts/auth-context"
import { Menu, User, HelpCircle } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from "@/components/ui/sheet"

export default function BookingMobileHeader() {
  const { user, logout, isAuthenticated } = useAuth()
  const [currency, setCurrency] = useState("BRL")
  const [language, setLanguage] = useState("pt-BR")

  return (
    <header className="bg-booking-blue text-white py-3 px-4 flex items-center justify-between">
      <Link href="/" className="flex items-center">
        <span className="text-xl font-bold text-white">Booking.com</span>
      </Link>

      <div className="flex items-center space-x-2">
        {isAuthenticated ? (
          <Link href="/account">
            <Button variant="ghost" className="text-white p-1">
              <User className="h-5 w-5" />
            </Button>
          </Link>
        ) : (
          <Link href="/login">
            <Button variant="ghost" className="text-white p-1">
              <User className="h-5 w-5" />
            </Button>
          </Link>
        )}

        <Sheet>
          <SheetTrigger asChild>
            <Button variant="ghost" className="text-white p-1">
              <Menu className="h-5 w-5" />
            </Button>
          </SheetTrigger>
          <SheetContent side="right" className="w-[85vw] sm:w-[385px]">
            <SheetHeader>
              <SheetTitle>Menu</SheetTitle>
            </SheetHeader>
            <div className="py-4">
              {isAuthenticated ? (
                <div className="border-b pb-4 mb-4">
                  <div className="font-bold mb-1">{user?.name}</div>
                  <div className="text-sm text-gray-500 mb-3">{user?.email}</div>
                  <div className="space-y-2">
                    <Link href="/account" className="block text-booking-blue-light">
                      Gerenciar conta
                    </Link>
                    <Link href="/bookings" className="block text-booking-blue-light">
                      Minhas reservas
                    </Link>
                    <button onClick={() => logout()} className="text-booking-blue-light">
                      Sair
                    </button>
                  </div>
                </div>
              ) : (
                <div className="border-b pb-4 mb-4">
                  <Link href="/register">
                    <Button className="w-full mb-2 bg-booking-blue">Criar conta</Button>
                  </Link>
                  <Link href="/login">
                    <Button variant="outline" className="w-full">
                      Entrar
                    </Button>
                  </Link>
                </div>
              )}

              <div className="space-y-4">
                <div className="border-b pb-4">
                  <h3 className="font-bold mb-2">Acomodações</h3>
                  <ul className="space-y-2">
                    <li>
                      <Link href="/hotels" className="text-booking-blue-light">
                        Hotéis
                      </Link>
                    </li>
                    <li>
                      <Link href="/apartments" className="text-booking-blue-light">
                        Apartamentos
                      </Link>
                    </li>
                    <li>
                      <Link href="/resorts" className="text-booking-blue-light">
                        Resorts
                      </Link>
                    </li>
                    <li>
                      <Link href="/villas" className="text-booking-blue-light">
                        Casas de temporada
                      </Link>
                    </li>
                    <li>
                      <Link href="/hostels" className="text-booking-blue-light">
                        Hostels
                      </Link>
                    </li>
                  </ul>
                </div>

                <div className="border-b pb-4">
                  <h3 className="font-bold mb-2">Outros serviços</h3>
                  <ul className="space-y-2">
                    <li>
                      <Link href="/flights" className="text-booking-blue-light">
                        Voos
                      </Link>
                    </li>
                    <li>
                      <Link href="/car-rentals" className="text-booking-blue-light">
                        Aluguel de carros
                      </Link>
                    </li>
                    <li>
                      <Link href="/attractions" className="text-booking-blue-light">
                        Atrações
                      </Link>
                    </li>
                    <li>
                      <Link href="/airport-taxis" className="text-booking-blue-light">
                        Táxis aeroporto
                      </Link>
                    </li>
                  </ul>
                </div>

                <div className="border-b pb-4">
                  <h3 className="font-bold mb-2">Configurações</h3>
                  <div className="flex items-center justify-between mb-2">
                    <span>Moeda</span>
                    <select
                      value={currency}
                      onChange={(e) => setCurrency(e.target.value)}
                      className="border rounded p-1"
                    >
                      <option value="BRL">BRL</option>
                      <option value="USD">USD</option>
                      <option value="EUR">EUR</option>
                    </select>
                  </div>
                  <div className="flex items-center justify-between">
                    <span>Idioma</span>
                    <select
                      value={language}
                      onChange={(e) => setLanguage(e.target.value)}
                      className="border rounded p-1"
                    >
                      <option value="pt-BR">Português</option>
                      <option value="en-US">English</option>
                      <option value="es">Español</option>
                    </select>
                  </div>
                </div>

                <div>
                  <Link href="/help" className="flex items-center text-booking-blue-light">
                    <HelpCircle className="h-4 w-4 mr-2" />
                    Central de ajuda
                  </Link>
                </div>
              </div>
            </div>
          </SheetContent>
        </Sheet>
      </div>
    </header>
  )
}
