import Link from "next/link"

export default function BookingFooter() {
  const currentYear = new Date().getFullYear()

  const destinations = [
    { name: "Rio de Janeiro", slug: "rio-de-janeiro" },
    { name: "São Paulo", slug: "sao-paulo" },
    { name: "Salvador", slug: "salvador" },
    { name: "Fortaleza", slug: "fortaleza" },
    { name: "Brasília", slug: "brasilia" },
    { name: "Gramado", slug: "gramado" },
    { name: "Florianópolis", slug: "florianopolis" },
    { name: "Porto de Galinhas", slug: "porto-de-galinhas" },
    { name: "Natal", slug: "natal" },
    { name: "Foz do Iguaçu", slug: "foz-do-iguacu" },
  ]

  const propertyTypes = [
    { name: "Hotéis", slug: "hotels" },
    { name: "Apartamentos", slug: "apartments" },
    { name: "Resorts", slug: "resorts" },
    { name: "Pousadas", slug: "inns" },
    { name: "Casas de temporada", slug: "vacation-homes" },
    { name: "Hostels", slug: "hostels" },
  ]

  const regions = [
    { name: "Nordeste", slug: "northeast" },
    { name: "Sudeste", slug: "southeast" },
    { name: "Sul", slug: "south" },
    { name: "Centro-Oeste", slug: "midwest" },
    { name: "Norte", slug: "north" },
  ]

  return (
    <footer className="bg-gray-100 pt-10 pb-6">
      <div className="booking-container">
        <div className="grid grid-cols-1 md:grid-cols-3 lg:grid-cols-5 gap-8 mb-8">
          <div>
            <h3 className="font-bold mb-4">Destinos populares</h3>
            <ul className="space-y-2">
              {destinations.map((destination) => (
                <li key={destination.slug}>
                  <Link
                    href={`/hotels?location=${destination.name}`}
                    className="text-sm text-booking-blue-light hover:underline"
                  >
                    {destination.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-bold mb-4">Tipos de acomodação</h3>
            <ul className="space-y-2">
              {propertyTypes.map((type) => (
                <li key={type.slug}>
                  <Link href={`/hotels?type=${type.slug}`} className="text-sm text-booking-blue-light hover:underline">
                    {type.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-bold mb-4">Regiões</h3>
            <ul className="space-y-2">
              {regions.map((region) => (
                <li key={region.slug}>
                  <Link
                    href={`/hotels?region=${region.slug}`}
                    className="text-sm text-booking-blue-light hover:underline"
                  >
                    {region.name}
                  </Link>
                </li>
              ))}
            </ul>
          </div>

          <div>
            <h3 className="font-bold mb-4">Para viajantes</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/help" className="text-sm text-booking-blue-light hover:underline">
                  Central de ajuda
                </Link>
              </li>
              <li>
                <Link href="/faq" className="text-sm text-booking-blue-light hover:underline">
                  Perguntas frequentes
                </Link>
              </li>
              <li>
                <Link href="/covid-19" className="text-sm text-booking-blue-light hover:underline">
                  Informações sobre COVID-19
                </Link>
              </li>
              <li>
                <Link href="/terms" className="text-sm text-booking-blue-light hover:underline">
                  Termos e condições
                </Link>
              </li>
              <li>
                <Link href="/privacy" className="text-sm text-booking-blue-light hover:underline">
                  Política de privacidade
                </Link>
              </li>
            </ul>
          </div>

          <div>
            <h3 className="font-bold mb-4">Para proprietários</h3>
            <ul className="space-y-2">
              <li>
                <Link href="/partners" className="text-sm text-booking-blue-light hover:underline">
                  Anuncie sua propriedade
                </Link>
              </li>
              <li>
                <Link href="/partners/help" className="text-sm text-booking-blue-light hover:underline">
                  Central de parceiros
                </Link>
              </li>
              <li>
                <Link href="/partners/terms" className="text-sm text-booking-blue-light hover:underline">
                  Termos para parceiros
                </Link>
              </li>
            </ul>
          </div>
        </div>

        <div className="border-t border-gray-300 pt-6 text-center">
          <p className="text-sm text-gray-600">
            Copyright &copy; {currentYear} Novo Booking. Todos os direitos reservados.
          </p>
        </div>
      </div>
    </footer>
  )
}
