"use client"

import { useState } from "react"
import Link from "next/link"
import Image from "next/image"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight } from "lucide-react"

interface Offer {
  id: number
  title: string
  description: string
  image: string
  link: string
  buttonText: string
}

export default function BookingOffers() {
  const [currentSlide, setCurrentSlide] = useState(0)
  const [offers] = useState<Offer[]>([
    {
      id: 1,
      title: "Viagens rápidas, seu próximo",
      description: "Encontre o destino perfeito para um fim de semana prolongado",
      image: "/weekend-getaway.png",
      link: "/hotels?purpose=weekend",
      buttonText: "Pesquisar",
    },
    {
      id: 2,
      title: "Ofertas para viajar de carro",
      description: "Encontre destinos próximos para viajar de carro",
      image: "/road-trip.png",
      link: "/hotels?purpose=road-trip",
      buttonText: "Explorar",
    },
  ])

  const nextSlide = () => {
    setCurrentSlide((prev) => (prev === offers.length - 1 ? 0 : prev + 1))
  }

  const prevSlide = () => {
    setCurrentSlide((prev) => (prev === 0 ? offers.length - 1 : prev - 1))
  }

  return (
    <div className="py-8">
      <h2 className="text-2xl font-bold mb-6">Ofertas</h2>

      <div className="relative">
        <div className="flex overflow-hidden">
          {offers.map((offer, index) => (
            <div
              key={offer.id}
              className={`w-full flex-shrink-0 transition-transform duration-500 ease-in-out ${
                index === currentSlide ? "block" : "hidden"
              }`}
            >
              <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                <div className="bg-booking-blue text-white p-6 rounded-lg flex flex-col justify-between">
                  <div>
                    <h3 className="text-xl font-bold mb-2">{offer.title}</h3>
                    <p className="mb-4">{offer.description}</p>
                  </div>
                  <Link href={offer.link}>
                    <Button className="bg-booking-blue-light hover:bg-opacity-90">{offer.buttonText}</Button>
                  </Link>
                </div>
                <div className="relative h-48 md:h-auto rounded-lg overflow-hidden">
                  <Image
                    src={offer.image || `/placeholder.svg?height=200&width=400&query=travel`}
                    alt={offer.title}
                    fill
                    className="object-cover"
                  />
                </div>
              </div>
            </div>
          ))}
        </div>

        {offers.length > 1 && (
          <>
            <button
              className="absolute left-2 top-1/2 transform -translate-y-1/2 bg-white rounded-full p-2 shadow-md"
              onClick={prevSlide}
            >
              <ChevronLeft className="h-5 w-5" />
            </button>
            <button
              className="absolute right-2 top-1/2 transform -translate-y-1/2 bg-white rounded-full p-2 shadow-md"
              onClick={nextSlide}
            >
              <ChevronRight className="h-5 w-5" />
            </button>
            <div className="absolute bottom-2 left-1/2 transform -translate-x-1/2 flex space-x-2">
              {offers.map((_, index) => (
                <button
                  key={index}
                  className={`w-2 h-2 rounded-full ${index === currentSlide ? "bg-booking-blue" : "bg-gray-300"}`}
                  onClick={() => setCurrentSlide(index)}
                />
              ))}
            </div>
          </>
        )}
      </div>
    </div>
  )
}
