"use client"

import type React from "react"

import { type ReactNode, useEffect, useState } from "react"
import { useIntersectionObserver } from "@/hooks/use-intersection-observer"

interface LazyLoadProps {
  children: ReactNode
  placeholder?: ReactNode
  threshold?: number
  rootMargin?: string
}

export default function LazyLoad({ children, placeholder, threshold = 0.1, rootMargin = "200px" }: LazyLoadProps) {
  const [shouldRender, setShouldRender] = useState(false)
  const { ref, hasIntersected } = useIntersectionObserver({
    threshold,
    rootMargin,
  })

  useEffect(() => {
    if (hasIntersected) {
      setShouldRender(true)
    }
  }, [hasIntersected])

  return (
    <div ref={ref as React.RefObject<HTMLDivElement>}>
      {shouldRender
        ? children
        : placeholder || <div className="animate-pulse bg-gray-200 dark:bg-gray-800 h-40 rounded-md" />}
    </div>
  )
}
