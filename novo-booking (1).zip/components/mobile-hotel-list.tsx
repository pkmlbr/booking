"use client"

import { useState, useEffect } from "react"
import Link from "next/link"
import { useRouter } from "next/navigation"
import Image from "next/image"
import { Star, MapPin, Wifi, Car, Coffee, Check } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Skeleton } from "@/components/ui/skeleton"
import ErrorWithRetry from "@/components/error-with-retry"

interface MobileHotelListProps {
  location?: string
  checkIn?: string
  checkOut?: string
  adults?: number
  children?: number
  page?: number
}

interface Hotel {
  id: string
  name: string
  city: string
  state: string
  starRating: number | null
  minPrice: number | null
  isFeatured: boolean
  description?: string
  rating?: number
  reviewCount?: number
  facilities?: string[]
  images: {
    id: string
    imageUrl: string
    isPrimary: boolean
  }[]
}

interface PaginationData {
  total: number
  page: number
  limit: number
  pages: number
}

export default function MobileHotelList({
  location,
  checkIn,
  checkOut,
  adults = 2,
  children = 0,
  page = 1,
}: MobileHotelListProps) {
  const router = useRouter()
  const [hotels, setHotels] = useState<Hotel[]>([])
  const [pagination, setPagination] = useState<PaginationData>({
    total: 0,
    page: 1,
    limit: 10,
    pages: 1,
  })
  const [loading, setLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  const fetchHotels = async () => {
    setLoading(true)
    setError(null)

    try {
      // Construir URL com parâmetros
      const params = new URLSearchParams()
      if (location) params.append("location", location)
      if (checkIn) params.append("checkIn", checkIn)
      if (checkOut) params.append("checkOut", checkOut)
      if (adults) params.append("adults", adults.toString())
      if (children) params.append("children", children.toString())
      if (page) params.append("page", page.toString())

      // Buscar hotéis da API
      const response = await fetch(`/api/hotels?${params.toString()}`, {
        cache: "no-store", // Importante: não usar cache para sempre obter os dados mais recentes
      })

      if (!response.ok) {
        throw new Error("Falha ao buscar hotéis")
      }

      const data = await response.json()

      // Adicionar dados fictícios para demonstração
      const enhancedHotels = data.hotels.map((hotel: Hotel) => ({
        ...hotel,
        description:
          hotel.description || "Este hotel oferece acomodações confortáveis em uma localização privilegiada.",
        rating: hotel.rating || Math.floor(Math.random() * 3) + 7, // Rating entre 7 e 9.9
        reviewCount: hotel.reviewCount || Math.floor(Math.random() * 1000) + 100,
        facilities: hotel.facilities || ["Wi-Fi", "Estacionamento", "Café da manhã", "Ar-condicionado"],
      }))

      setHotels(enhancedHotels)
      setPagination(data.pagination)
    } catch (err) {
      console.error("Erro ao buscar hotéis:", err)
      setError("Não foi possível carregar os hotéis. Tente novamente.")
    } finally {
      setLoading(false)
    }
  }

  useEffect(() => {
    fetchHotels()
  }, [location, checkIn, checkOut, adults, children, page])

  const handlePageChange = (newPage: number) => {
    // Atualizar a URL com a nova página
    const params = new URLSearchParams(window.location.search)
    params.set("page", newPage.toString())
    router.push(`/hotels?${params.toString()}`)
  }

  const getRatingLabel = (rating: number) => {
    if (rating >= 9.0) return "Excelente"
    if (rating >= 8.0) return "Muito bom"
    if (rating >= 7.0) return "Bom"
    if (rating >= 6.0) return "Agradável"
    return "Avaliado"
  }

  const getRatingColor = (rating: number) => {
    if (rating >= 9.0) return "bg-[#004cb8]"
    if (rating >= 8.0) return "bg-[#0a6a4a]"
    if (rating >= 7.0) return "bg-[#6a8a00]"
    if (rating >= 6.0) return "bg-[#c26b00]"
    return "bg-[#767676]"
  }

  if (loading) {
    return (
      <div className="p-4 space-y-4">
        {[...Array(5)].map((_, index) => (
          <div key={index} className="border rounded-lg overflow-hidden bg-white">
            <Skeleton className="h-48 w-full" />
            <div className="p-4 space-y-2">
              <Skeleton className="h-5 w-3/4" />
              <Skeleton className="h-4 w-1/2" />
              <Skeleton className="h-4 w-full" />
              <div className="flex justify-between items-center">
                <Skeleton className="h-5 w-1/3" />
                <Skeleton className="h-5 w-1/4" />
              </div>
            </div>
          </div>
        ))}
      </div>
    )
  }

  if (error) {
    return (
      <div className="p-4">
        <ErrorWithRetry message={error} onRetry={fetchHotels} />
      </div>
    )
  }

  if (hotels.length === 0) {
    return (
      <div className="p-4 text-center py-12">
        <h2 className="text-xl font-semibold mb-4">Nenhum hotel encontrado</h2>
        <p className="text-gray-500 mb-6">Tente ajustar seus filtros ou buscar por outra localização.</p>
        <Button onClick={() => router.push("/hotels")} className="bg-booking-blue">
          Ver todos os hotéis
        </Button>
      </div>
    )
  }

  return (
    <div className="p-4">
      <div className="mb-4">
        <h2 className="text-lg font-semibold">
          {pagination.total} {pagination.total === 1 ? "propriedade encontrada" : "propriedades encontradas"}
          {location ? ` em "${location}"` : ""}
        </h2>
      </div>

      <div className="space-y-4">
        {hotels.map((hotel) => (
          <Link href={`/hotels/${hotel.id}`} key={hotel.id}>
            <div className="border rounded-lg overflow-hidden bg-white">
              <div className="relative h-48 w-full">
                <Image
                  src={
                    hotel.images[0]?.imageUrl ||
                    `/placeholder.svg?height=200&width=300&query=hotel+em+${encodeURIComponent(hotel.city) || "/placeholder.svg"}`
                  }
                  alt={hotel.name}
                  fill
                  className="object-cover"
                />
                {hotel.isFeatured && (
                  <div className="absolute top-2 left-2 bg-booking-blue text-white text-xs px-2 py-1 rounded">
                    Destaque
                  </div>
                )}
              </div>
              <div className="p-3">
                <div className="flex justify-between items-start">
                  <h3 className="font-bold text-booking-blue-light">{hotel.name}</h3>
                  {hotel.starRating && (
                    <div className="flex">
                      {Array.from({ length: Math.floor(hotel.starRating) }).map((_, i) => (
                        <Star key={i} className="h-3 w-3 fill-yellow-400 text-yellow-400" />
                      ))}
                    </div>
                  )}
                </div>

                <p className="text-xs text-gray-600 mb-1 flex items-center">
                  <MapPin className="h-3 w-3 mr-1" />
                  {hotel.city}, {hotel.state}
                </p>

                <p className="text-xs mb-2 line-clamp-2">{hotel.description}</p>

                <div className="flex flex-wrap gap-1 mb-2">
                  {hotel.facilities?.slice(0, 3).map((facility, index) => (
                    <span key={index} className="text-xs bg-gray-100 px-1 py-0.5 rounded flex items-center">
                      {facility === "Wi-Fi" && <Wifi className="h-2 w-2 mr-0.5" />}
                      {facility === "Estacionamento" && <Car className="h-2 w-2 mr-0.5" />}
                      {facility === "Café da manhã" && <Coffee className="h-2 w-2 mr-0.5" />}
                      {facility === "Ar-condicionado" && <Check className="h-2 w-2 mr-0.5" />}
                      {facility}
                    </span>
                  ))}
                </div>

                <div className="flex justify-between items-center">
                  <div className="flex items-center">
                    <div
                      className={`${getRatingColor(hotel.rating || 0)} text-white font-bold px-1 py-0.5 rounded text-xs mr-1`}
                    >
                      {hotel.rating?.toFixed(1)}
                    </div>
                    <span className="text-xs font-medium">{getRatingLabel(hotel.rating || 0)}</span>
                    <span className="text-xs text-gray-500 ml-1">({hotel.reviewCount})</span>
                  </div>
                  <div>
                    {hotel.minPrice ? (
                      <p className="font-bold text-sm">R$ {hotel.minPrice.toFixed(2)}</p>
                    ) : (
                      <p className="text-xs text-gray-500">Preço não disponível</p>
                    )}
                  </div>
                </div>
              </div>
            </div>
          </Link>
        ))}
      </div>

      {/* Paginação */}
      {pagination.pages > 1 && (
        <div className="flex justify-center mt-6">
          <div className="flex items-center space-x-1">
            <Button
              variant="outline"
              size="sm"
              onClick={() => handlePageChange(pagination.page - 1)}
              disabled={pagination.page === 1}
              className="h-8 w-8 p-0"
            >
              &lt;
            </Button>

            {[...Array(pagination.pages)].map((_, i) => {
              const pageNumber = i + 1
              // Mostrar apenas páginas próximas à atual
              if (
                pageNumber === 1 ||
                pageNumber === pagination.pages ||
                (pageNumber >= pagination.page - 1 && pageNumber <= pagination.page + 1)
              ) {
                return (
                  <Button
                    key={pageNumber}
                    variant={pageNumber === pagination.page ? "default" : "outline"}
                    onClick={() => handlePageChange(pageNumber)}
                    className={`h-8 w-8 p-0 ${pageNumber === pagination.page ? "bg-booking-blue" : ""}`}
                  >
                    {pageNumber}
                  </Button>
                )
              }

              // Mostrar reticências para páginas omitidas
              if (pageNumber === 2 || pageNumber === pagination.pages - 1) {
                return (
                  <span key={`ellipsis-${pageNumber}`} className="px-1">
                    ...
                  </span>
                )
              }

              return null
            })}

            <Button
              variant="outline"
              size="sm"
              onClick={() => handlePageChange(pagination.page + 1)}
              disabled={pagination.page === pagination.pages}
              className="h-8 w-8 p-0"
            >
              &gt;
            </Button>
          </div>
        </div>
      )}
    </div>
  )
}
