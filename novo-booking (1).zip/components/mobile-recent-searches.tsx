"use client"

import { useState } from "react"
import Image from "next/image"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import { useRouter } from "next/navigation"

interface RecentSearch {
  id: string
  location: string
  image: string
  checkIn: Date
  checkOut: Date
  guests: number
}

export default function MobileRecentSearches() {
  const router = useRouter()
  const [searches, setSearches] = useState<RecentSearch[]>([
    {
      id: "1",
      location: "Brasília",
      image: "/brasilia.png",
      checkIn: new Date(2023, 11, 15),
      checkOut: new Date(2023, 11, 18),
      guests: 2,
    },
    {
      id: "2",
      location: "São Paulo",
      image: "/sao-paulo.png",
      checkIn: new Date(2023, 11, 20),
      checkOut: new Date(2023, 11, 23),
      guests: 3,
    },
    {
      id: "3",
      location: "Rio de Janeiro",
      image: "/rio-de-janeiro-beach.png",
      checkIn: new Date(2023, 11, 25),
      checkOut: new Date(2023, 11, 30),
      guests: 2,
    },
  ])

  const handleSearchClick = (search: RecentSearch) => {
    const params = new URLSearchParams()
    params.append("location", search.location)
    params.append("checkIn", format(search.checkIn, "yyyy-MM-dd"))
    params.append("checkOut", format(search.checkOut, "yyyy-MM-dd"))
    params.append("adults", search.guests.toString())

    router.push(`/hotels?${params.toString()}`)
  }

  if (searches.length === 0) {
    return null
  }

  return (
    <div className="py-4">
      <h2 className="mobile-section-title">Suas pesquisas recentes</h2>

      <div className="space-y-0">
        {searches.map((search) => (
          <div key={search.id} className="mobile-recent-search" onClick={() => handleSearchClick(search)}>
            <div className="relative w-16 h-16 flex-shrink-0">
              <Image
                src={search.image || `/placeholder.svg?height=100&width=100&query=${search.location}`}
                alt={search.location}
                fill
                className="object-cover rounded-md"
              />
            </div>
            <div>
              <h3 className="font-bold text-booking-blue-light">{search.location}</h3>
              <p className="text-xs text-gray-600">
                {format(search.checkIn, "d MMM", { locale: ptBR })} -{" "}
                {format(search.checkOut, "d MMM", { locale: ptBR })}
              </p>
              <p className="text-xs text-gray-600">
                {search.guests} {search.guests === 1 ? "hóspede" : "hóspedes"}
              </p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
