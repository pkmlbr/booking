"use client"

import { useState } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"

interface Destination {
  id: number
  name: string
  state: string
  image: string
  hotels: number
  slug: string
}

export default function PopularDestinations() {
  const router = useRouter()
  const [destinations, setDestinations] = useState<Destination[]>([
    {
      id: 1,
      name: "Brasília",
      state: "DF",
      image: "/brasilia.png",
      hotels: 120,
      slug: "brasilia",
    },
    {
      id: 2,
      name: "São Paulo",
      state: "SP",
      image: "/sao-paulo.png",
      hotels: 450,
      slug: "sao-paulo",
    },
    {
      id: 3,
      name: "Rio de Janeiro",
      state: "RJ",
      image: "/rio-de-janeiro-beach.png",
      hotels: 380,
      slug: "rio-de-janeiro",
    },
    {
      id: 4,
      name: "Fortaleza",
      state: "CE",
      image: "/fortaleza.png",
      hotels: 210,
      slug: "fortaleza",
    },
    {
      id: 5,
      name: "Salvador",
      state: "BA",
      image: "/salvador.png",
      hotels: 180,
      slug: "salvador",
    },
  ])

  const handleDestinationClick = (destination: Destination) => {
    router.push(`/hotels?location=${destination.name}`)
  }

  return (
    <div className="py-8">
      <h2 className="text-2xl font-bold mb-6">Destinos mais procurados</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {destinations.slice(0, 3).map((destination, index) => (
          <div
            key={destination.id}
            className="relative overflow-hidden rounded-lg cursor-pointer h-64"
            onClick={() => handleDestinationClick(destination)}
          >
            <Image
              src={destination.image || `/placeholder.svg?height=300&width=500&query=${destination.name}`}
              alt={destination.name}
              fill
              className="object-cover transition-transform duration-300 hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
            <div className="absolute bottom-0 left-0 p-4 text-white">
              <h3 className="text-xl font-bold">{destination.name}</h3>
              <p>{destination.hotels} propriedades</p>
            </div>
          </div>
        ))}
      </div>

      <div className="grid grid-cols-2 md:grid-cols-3 gap-4 mt-4">
        {destinations.slice(3).map((destination) => (
          <div
            key={destination.id}
            className="relative overflow-hidden rounded-lg cursor-pointer h-40"
            onClick={() => handleDestinationClick(destination)}
          >
            <Image
              src={destination.image || `/placeholder.svg?height=200&width=300&query=${destination.name}`}
              alt={destination.name}
              fill
              className="object-cover transition-transform duration-300 hover:scale-110"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-black/70 to-transparent"></div>
            <div className="absolute bottom-0 left-0 p-4 text-white">
              <h3 className="text-lg font-bold">{destination.name}</h3>
              <p className="text-sm">{destination.hotels} propriedades</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
