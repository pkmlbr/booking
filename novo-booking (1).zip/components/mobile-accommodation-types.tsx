"use client"

import { useState } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"

interface AccommodationType {
  id: number
  name: string
  image: string
  count: number
  type: string
}

export default function MobileAccommodationTypes() {
  const router = useRouter()
  const [types] = useState<AccommodationType[]>([
    {
      id: 1,
      name: "Hotéis",
      image: "/hotel-type.png",
      count: 865,
      type: "hotel",
    },
    {
      id: 2,
      name: "Apartamentos",
      image: "/apartment-type.png",
      count: 432,
      type: "apartment",
    },
    {
      id: 3,
      name: "Casas",
      image: "/vacation-home-type.png",
      count: 321,
      type: "vacation-home",
    },
    {
      id: 4,
      name: "Pousadas",
      image: "/inn-type.png",
      count: 267,
      type: "inn",
    },
  ])

  const handleTypeClick = (type: AccommodationType) => {
    router.push(`/hotels?type=${type.type}`)
  }

  return (
    <div className="py-4">
      <h2 className="mobile-section-title">Pesquise por tipo de acomodação</h2>

      <div className="scroll-container">
        {types.map((type) => (
          <div key={type.id} className="mobile-accommodation-type w-24" onClick={() => handleTypeClick(type)}>
            <div className="relative w-20 h-20 mx-auto">
              <Image
                src={type.image || `/placeholder.svg?height=100&width=100&query=${type.name}`}
                alt={type.name}
                fill
                className="object-cover rounded-md"
              />
            </div>
            <div className="text-center mt-1">
              <h3 className="text-sm font-medium">{type.name}</h3>
              <p className="text-xs text-gray-500">{type.count}</p>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
