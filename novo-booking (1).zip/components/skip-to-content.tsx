"use client"

import { useState } from "react"
import { cn } from "@/lib/utils"

export default function SkipToContent() {
  const [isFocused, setIsFocused] = useState(false)

  return (
    <a
      href="#main-content"
      className={cn(
        "fixed top-0 left-0 p-3 bg-primary text-white z-50 transform -translate-y-full focus:translate-y-0 transition-transform",
        isFocused && "translate-y-0",
      )}
      onFocus={() => setIsFocused(true)}
      onBlur={() => setIsFocused(false)}
    >
      Pular para o conteúdo principal
    </a>
  )
}
