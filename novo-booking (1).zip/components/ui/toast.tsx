"use client"

import { useEffect, useState } from "react"
import { X, AlertCircle, CheckCircle, Info } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import { cn } from "@/lib/utils"

export function Toaster() {
  const { toasts, dismiss } = useToast()
  const [mounted, setMounted] = useState(false)

  useEffect(() => {
    setMounted(true)
  }, [])

  if (!mounted) return null

  return (
    <div className="fixed top-0 right-0 z-50 p-4 space-y-4 w-full max-w-sm">
      {toasts.map((toast) => (
        <div
          key={toast.id}
          className={cn(
            "bg-white dark:bg-gray-800 rounded-lg shadow-lg border p-4 flex items-start gap-3 animate-in slide-in-from-right",
            toast.variant === "destructive" && "border-red-500",
            toast.variant === "success" && "border-green-500",
          )}
        >
          {toast.variant === "destructive" && <AlertCircle className="h-5 w-5 text-red-500" />}
          {toast.variant === "success" && <CheckCircle className="h-5 w-5 text-green-500" />}
          {toast.variant === "default" && <Info className="h-5 w-5 text-blue-500" />}

          <div className="flex-1">
            <h3 className="font-medium">{toast.title}</h3>
            {toast.description && <p className="text-sm text-gray-500 dark:text-gray-400">{toast.description}</p>}
          </div>

          <button
            onClick={() => dismiss(toast.id)}
            className="text-gray-400 hover:text-gray-500 dark:text-gray-500 dark:hover:text-gray-400"
          >
            <X className="h-4 w-4" />
          </button>
        </div>
      ))}
    </div>
  )
}
