"use client"

import { useEffect } from "react"

export default function PerformanceMonitor() {
  useEffect(() => {
    if (typeof window === "undefined" || !("performance" in window)) return

    // Monitorar carregamento da página
    window.addEventListener("load", () => {
      setTimeout(() => {
        const perfData = window.performance.timing
        const pageLoadTime = perfData.loadEventEnd - perfData.navigationStart
        const domReadyTime = perfData.domContentLoadedEventEnd - perfData.navigationStart

        // Enviar métricas para o servidor
        fetch("/api/analytics/performance", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
          body: JSON.stringify({
            pageLoadTime,
            domReadyTime,
            url: window.location.href,
          }),
        }).catch((err) => {
          console.error("Erro ao enviar métricas de performance:", err)
        })

        // Registrar no console em desenvolvimento
        if (process.env.NODE_ENV === "development") {
          console.log(`Tempo de carregamento da página: ${pageLoadTime}ms`)
          console.log(`Tempo de DOM pronto: ${domReadyTime}ms`)
        }
      }, 0)
    })

    // Monitorar recursos
    if (window.performance && window.performance.getEntriesByType) {
      window.addEventListener("load", () => {
        setTimeout(() => {
          const resources = window.performance.getEntriesByType("resource")

          // Identificar recursos lentos (> 1s)
          const slowResources = resources.filter((resource) => resource.duration > 1000)

          if (slowResources.length > 0 && process.env.NODE_ENV === "development") {
            console.warn("Recursos lentos detectados:")
            slowResources.forEach((resource) => {
              console.warn(`${resource.name}: ${resource.duration.toFixed(2)}ms`)
            })
          }
        }, 0)
      })
    }
  }, [])

  return null
}
