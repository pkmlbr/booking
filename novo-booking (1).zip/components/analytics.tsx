"use client"

import { useEffect } from "react"
import { usePathname, useSearchParams } from "next/navigation"

export default function Analytics() {
  const pathname = usePathname()
  const searchParams = useSearchParams()

  useEffect(() => {
    if (typeof window.gtag !== "function") return

    const url = pathname + (searchParams?.toString() ? `?${searchParams.toString()}` : "")

    window.gtag("config", "G-MEASUREMENT_ID", {
      page_path: url,
    })

    // Registrar visualização de página
    fetch("/api/analytics/pageview", {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        path: url,
        referrer: document.referrer || null,
      }),
    }).catch((err) => {
      console.error("Erro ao registrar visualização de página:", err)
    })
  }, [pathname, searchParams])

  return null
}
