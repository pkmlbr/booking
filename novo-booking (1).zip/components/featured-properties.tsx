"use client"

import { useState } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"

interface Property {
  id: string
  name: string
  location: string
  image: string
  rating: number
  reviewCount: number
  price: number
  currency: string
  type: string
}

export default function FeaturedProperties() {
  const router = useRouter()
  const [properties, setProperties] = useState<Property[]>([
    {
      id: "1",
      name: "Hotel Atlântico Business",
      location: "Centro, Rio de Janeiro",
      image: "/hotel-atlantico.png",
      rating: 8.4,
      reviewCount: 2345,
      price: 289,
      currency: "BRL",
      type: "Hotel",
    },
    {
      id: "2",
      name: "Pousada Recanto da Serra",
      location: "Gramado, Rio Grande do Sul",
      image: "/pousada-gramado.png",
      rating: 9.2,
      reviewCount: 876,
      price: 450,
      currency: "BRL",
      type: "Pousada",
    },
    {
      id: "3",
      name: "Flat Premium Salvador",
      location: "Barra, Salvador",
      image: "/flat-salvador.png",
      rating: 8.8,
      reviewCount: 1234,
      price: 320,
      currency: "BRL",
      type: "Flat",
    },
    {
      id: "4",
      name: "Pousada Maravilha de Olinda",
      location: "Centro Histórico, Olinda",
      image: "/pousada-olinda.png",
      rating: 9.0,
      reviewCount: 567,
      price: 280,
      currency: "BRL",
      type: "Pousada",
    },
  ])

  const handlePropertyClick = (property: Property) => {
    router.push(`/hotels/${property.id}`)
  }

  const getRatingLabel = (rating: number) => {
    if (rating >= 9.0) return "Excelente"
    if (rating >= 8.0) return "Muito bom"
    if (rating >= 7.0) return "Bom"
    if (rating >= 6.0) return "Agradável"
    return "Avaliado"
  }

  const getRatingColor = (rating: number) => {
    if (rating >= 9.0) return "bg-[#004cb8]"
    if (rating >= 8.0) return "bg-[#0a6a4a]"
    if (rating >= 7.0) return "bg-[#6a8a00]"
    if (rating >= 6.0) return "bg-[#c26b00]"
    return "bg-[#767676]"
  }

  return (
    <div className="py-8">
      <h2 className="text-2xl font-bold mb-6">Casas e apartamentos que os hóspedes amam</h2>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        {properties.map((property) => (
          <div key={property.id} className="cursor-pointer" onClick={() => handlePropertyClick(property)}>
            <div className="relative h-48 rounded-lg overflow-hidden mb-2">
              <Image
                src={property.image || `/placeholder.svg?height=200&width=300&query=${property.name}`}
                alt={property.name}
                fill
                className="object-cover transition-transform duration-300 hover:scale-110"
              />
            </div>
            <h3 className="font-bold text-booking-blue-light hover:underline">{property.name}</h3>
            <p className="text-sm text-gray-600 mb-1">{property.location}</p>
            <div className="flex items-center mb-2">
              <div className={`${getRatingColor(property.rating)} text-white font-bold px-1 rounded mr-2`}>
                {property.rating}
              </div>
              <span className="font-medium">{getRatingLabel(property.rating)}</span>
              <span className="text-gray-500 ml-2">{property.reviewCount} avaliações</span>
            </div>
            <p className="text-sm">
              <span className="font-bold">R$ {property.price}</span> / diária
            </p>
          </div>
        ))}
      </div>
    </div>
  )
}
