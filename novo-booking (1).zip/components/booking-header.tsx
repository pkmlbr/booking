"use client"

import { useState } from "react"
import Link from "next/link"
import { useAuth } from "@/contexts/auth-context"
import {
  Bed,
  PlaneTakeoff,
  Car,
  CarTaxiFrontIcon as Taxi,
  ActivityIcon as Attractions,
  CalendarClock,
  Globe,
  Bell,
  HelpCircle,
  User,
  Menu,
  X,
} from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

export default function BookingHeader() {
  const { user, logout, isAuthenticated } = useAuth()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)
  const [currency, setCurrency] = useState("BRL")
  const [language, setLanguage] = useState("pt-BR")

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen)
  }

  return (
    <header className="bg-booking-blue text-white">
      <div className="booking-container py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Link href="/" className="flex items-center mr-6">
              <span className="text-2xl font-bold text-white">Booking.com</span>
            </Link>

            <nav className="hidden md:flex items-center space-x-6">
              <Link href="/hotels" className="flex items-center text-white hover:text-gray-200">
                <Bed className="h-5 w-5 mr-1" />
                <span>Hospedagem</span>
              </Link>
              <Link href="/flights" className="flex items-center text-white hover:text-gray-200">
                <PlaneTakeoff className="h-5 w-5 mr-1" />
                <span>Voos</span>
              </Link>
              <Link href="/car-rentals" className="flex items-center text-white hover:text-gray-200">
                <Car className="h-5 w-5 mr-1" />
                <span>Aluguel de carros</span>
              </Link>
              <Link href="/attractions" className="flex items-center text-white hover:text-gray-200">
                <Attractions className="h-5 w-5 mr-1" />
                <span>Atrações</span>
              </Link>
              <Link href="/taxis" className="flex items-center text-white hover:text-gray-200">
                <Taxi className="h-5 w-5 mr-1" />
                <span>Táxis</span>
              </Link>
            </nav>
          </div>

          <div className="flex items-center space-x-4">
            {isAuthenticated ? (
              <>
                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="text-white hover:bg-booking-blue-light">
                      <Bell className="h-5 w-5 mr-1" />
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <DropdownMenuLabel>Notificações</DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <div className="p-3 text-center text-sm text-gray-500">Nenhuma notificação no momento</div>
                  </DropdownMenuContent>
                </DropdownMenu>

                <DropdownMenu>
                  <DropdownMenuTrigger asChild>
                    <Button variant="ghost" className="text-white hover:bg-booking-blue-light">
                      <User className="h-5 w-5 mr-1" />
                      <span className="hidden sm:inline">{user?.name?.split(" ")[0]}</span>
                    </Button>
                  </DropdownMenuTrigger>
                  <DropdownMenuContent align="end" className="w-56">
                    <DropdownMenuLabel>Minha Conta</DropdownMenuLabel>
                    <DropdownMenuLabel className="font-normal text-sm text-muted-foreground">
                      {user?.email}
                    </DropdownMenuLabel>
                    <DropdownMenuSeparator />
                    <Link href="/account">
                      <DropdownMenuItem>
                        <User className="mr-2 h-4 w-4" />
                        <span>Gerenciar conta</span>
                      </DropdownMenuItem>
                    </Link>
                    <Link href="/bookings">
                      <DropdownMenuItem>
                        <CalendarClock className="mr-2 h-4 w-4" />
                        <span>Reservas</span>
                      </DropdownMenuItem>
                    </Link>
                    {(user?.role === "ADMIN" || user?.role === "SUPER_ADMIN") && (
                      <Link href="/admin">
                        <DropdownMenuItem>
                          <span>Painel Admin</span>
                        </DropdownMenuItem>
                      </Link>
                    )}
                    <DropdownMenuSeparator />
                    <DropdownMenuItem onClick={() => logout()}>
                      <span>Sair</span>
                    </DropdownMenuItem>
                  </DropdownMenuContent>
                </DropdownMenu>
              </>
            ) : (
              <div className="flex items-center space-x-2">
                <Link href="/register">
                  <Button variant="ghost" className="text-white hover:bg-booking-blue-light">
                    Cadastre-se
                  </Button>
                </Link>
                <Link href="/login">
                  <Button variant="ghost" className="text-white hover:bg-booking-blue-light">
                    Entrar
                  </Button>
                </Link>
              </div>
            )}

            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <Button variant="ghost" className="text-white hover:bg-booking-blue-light">
                  <Globe className="h-5 w-5 mr-1" />
                  <span className="hidden sm:inline">{currency}</span>
                </Button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end">
                <DropdownMenuLabel>Moeda</DropdownMenuLabel>
                <DropdownMenuSeparator />
                <DropdownMenuItem onClick={() => setCurrency("BRL")}>BRL - Real Brasileiro</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setCurrency("USD")}>USD - Dólar Americano</DropdownMenuItem>
                <DropdownMenuItem onClick={() => setCurrency("EUR")}>EUR - Euro</DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>

            <Button variant="ghost" className="text-white hover:bg-booking-blue-light hidden md:flex">
              <HelpCircle className="h-5 w-5" />
            </Button>

            {/* Mobile Menu Button */}
            <Button
              variant="ghost"
              className="md:hidden text-white hover:bg-booking-blue-light"
              onClick={toggleMobileMenu}
              aria-label={mobileMenuOpen ? "Fechar menu" : "Abrir menu"}
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </Button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <nav className="md:hidden mt-4 pb-4 space-y-4">
            <Link
              href="/hotels"
              className="flex items-center text-white hover:text-gray-200 py-2"
              onClick={() => setMobileMenuOpen(false)}
            >
              <Bed className="h-5 w-5 mr-2" />
              <span>Hospedagem</span>
            </Link>
            <Link
              href="/flights"
              className="flex items-center text-white hover:text-gray-200 py-2"
              onClick={() => setMobileMenuOpen(false)}
            >
              <PlaneTakeoff className="h-5 w-5 mr-2" />
              <span>Voos</span>
            </Link>
            <Link
              href="/car-rentals"
              className="flex items-center text-white hover:text-gray-200 py-2"
              onClick={() => setMobileMenuOpen(false)}
            >
              <Car className="h-5 w-5 mr-2" />
              <span>Aluguel de carros</span>
            </Link>
            <Link
              href="/attractions"
              className="flex items-center text-white hover:text-gray-200 py-2"
              onClick={() => setMobileMenuOpen(false)}
            >
              <Attractions className="h-5 w-5 mr-2" />
              <span>Atrações</span>
            </Link>
            <Link
              href="/taxis"
              className="flex items-center text-white hover:text-gray-200 py-2"
              onClick={() => setMobileMenuOpen(false)}
            >
              <Taxi className="h-5 w-5 mr-2" />
              <span>Táxis</span>
            </Link>
          </nav>
        )}
      </div>
    </header>
  )
}
