"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Label } from "@/components/ui/label"
import { MessageSquare, ThumbsUp, ThumbsDown, X, Send, Loader2 } from "lucide-react"

export default function FeedbackWidget() {
  const [isOpen, setIsOpen] = useState(false)
  const [feedbackType, setFeedbackType] = useState<"positive" | "negative" | null>(null)
  const [feedbackText, setFeedbackText] = useState("")
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)

  const handleSubmit = async () => {
    if (!feedbackType) return

    setIsSubmitting(true)

    try {
      await fetch("/api/feedback", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          type: feedbackType,
          text: feedbackText,
          url: window.location.href,
        }),
      })

      setIsSubmitted(true)

      // Resetar após 3 segundos
      setTimeout(() => {
        setIsOpen(false)

        // Resetar estado após fechar
        setTimeout(() => {
          setFeedbackType(null)
          setFeedbackText("")
          setIsSubmitted(false)
        }, 300)
      }, 3000)
    } catch (error) {
      console.error("Erro ao enviar feedback:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <>
      <Button
        className="fixed bottom-4 right-4 rounded-full shadow-lg z-50"
        size="icon"
        onClick={() => setIsOpen(true)}
        aria-label="Enviar feedback"
      >
        <MessageSquare className="h-5 w-5" />
      </Button>

      {isOpen && (
        <div className="fixed bottom-20 right-4 w-80 bg-white dark:bg-gray-800 rounded-lg shadow-xl z-50 p-4 border border-gray-200 dark:border-gray-700">
          <div className="flex justify-between items-center mb-4">
            <h3 className="font-semibold">Enviar feedback</h3>
            <Button
              variant="ghost"
              size="icon"
              className="h-6 w-6"
              onClick={() => setIsOpen(false)}
              aria-label="Fechar"
            >
              <X className="h-4 w-4" />
            </Button>
          </div>

          {!isSubmitted ? (
            <>
              <div className="mb-4">
                <p className="text-sm text-muted-foreground mb-2">Como está sua experiência?</p>
                <RadioGroup
                  value={feedbackType || ""}
                  onValueChange={(value) => setFeedbackType(value as "positive" | "negative")}
                  className="flex space-x-4"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="positive" id="positive" />
                    <Label htmlFor="positive" className="flex items-center">
                      <ThumbsUp className="h-4 w-4 mr-1" />
                      Boa
                    </Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="negative" id="negative" />
                    <Label htmlFor="negative" className="flex items-center">
                      <ThumbsDown className="h-4 w-4 mr-1" />
                      Ruim
                    </Label>
                  </div>
                </RadioGroup>
              </div>

              <div className="mb-4">
                <Textarea
                  placeholder="Compartilhe seus comentários (opcional)"
                  value={feedbackText}
                  onChange={(e) => setFeedbackText(e.target.value)}
                  rows={3}
                />
              </div>

              <Button className="w-full" onClick={handleSubmit} disabled={!feedbackType || isSubmitting}>
                {isSubmitting ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Enviando...
                  </>
                ) : (
                  <>
                    <Send className="mr-2 h-4 w-4" />
                    Enviar feedback
                  </>
                )}
              </Button>
            </>
          ) : (
            <div className="text-center py-4">
              <ThumbsUp className="h-12 w-12 mx-auto mb-2 text-green-500" />
              <p className="font-medium">Obrigado pelo feedback!</p>
              <p className="text-sm text-muted-foreground">Sua opinião é muito importante para nós.</p>
            </div>
          )}
        </div>
      )}
    </>
  )
}
