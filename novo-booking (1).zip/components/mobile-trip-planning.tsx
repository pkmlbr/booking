"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { Car, Plane, Calendar, CreditCard } from "lucide-react"

interface TripOption {
  id: string
  name: string
  icon: React.ReactNode
}

export default function MobileTripPlanning() {
  const router = useRouter()
  const [options] = useState<TripOption[]>([
    {
      id: "car",
      name: "Carro",
      icon: <Car className="h-5 w-5" />,
    },
    {
      id: "flight",
      name: "Voo",
      icon: <Plane className="h-5 w-5" />,
    },
    {
      id: "attractions",
      name: "Atrações",
      icon: <Calendar className="h-5 w-5" />,
    },
    {
      id: "taxi",
      name: "Táxi",
      icon: <CreditCard className="h-5 w-5" />,
    },
  ])

  const [destinations] = useState([
    {
      id: 1,
      name: "Brasília",
      image: "/brasilia.png",
      distance: "12 km",
    },
    {
      id: 2,
      name: "Santos Dumont",
      image: "/santos-dumont.png",
      distance: "15 km",
    },
    {
      id: 3,
      name: "Ouro Preto",
      image: "/ouro-preto.png",
      distance: "20 km",
    },
    {
      id: 4,
      name: "São Luís",
      image: "/sao-luis.png",
      distance: "25 km",
    },
    {
      id: 5,
      name: "Ilha Grande",
      image: "/ilha-grande.png",
      distance: "30 km",
    },
  ])

  return (
    <div className="py-4">
      <h2 className="mobile-section-title">Planeje sua viagem fácil e rápido</h2>
      <p className="text-sm text-gray-500 px-4 mb-3">Encontre seu meio de transporte ideal para sua próxima aventura</p>

      <div className="scroll-container mb-4">
        {options.map((option) => (
          <div key={option.id} className="flex flex-col items-center w-20">
            <div className="w-12 h-12 rounded-full bg-gray-100 flex items-center justify-center mb-1">
              {option.icon}
            </div>
            <span className="text-xs">{option.name}</span>
          </div>
        ))}
      </div>

      <div className="scroll-container">
        {destinations.map((destination) => (
          <div key={destination.id} className="w-40 flex-shrink-0">
            <div className="relative h-24 rounded-md overflow-hidden mb-1">
              <Image
                src={destination.image || `/placeholder.svg?height=100&width=160&query=${destination.name}`}
                alt={destination.name}
                fill
                className="object-cover"
              />
            </div>
            <h3 className="text-sm font-medium">{destination.name}</h3>
            <p className="text-xs text-gray-500">{destination.distance}</p>
          </div>
        ))}
      </div>
    </div>
  )
}
