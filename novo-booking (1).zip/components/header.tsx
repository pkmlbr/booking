"use client"

import { useState } from "react"
import Link from "next/link"
import { useAuth } from "@/contexts/auth-context"
import { ThemeToggle } from "@/components/theme-toggle"
import { Menu, X, User, LogOut, BookOpen, Settings } from "lucide-react"
import { Button } from "@/components/ui/button"
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuLabel,
  DropdownMenuSeparator,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu"

export default function Header() {
  const { user, logout, isAuthenticated } = useAuth()
  const [mobileMenuOpen, setMobileMenuOpen] = useState(false)

  const toggleMobileMenu = () => {
    setMobileMenuOpen(!mobileMenuOpen)
  }

  return (
    <header className="bg-white dark:bg-gray-900 shadow-sm sticky top-0 z-50">
      <div className="container mx-auto px-4 py-3">
        <div className="flex items-center justify-between">
          <div className="flex items-center">
            <Link href="/" className="flex items-center">
              <span className="text-2xl font-bold text-primary">Novo Booking</span>
            </Link>
          </div>

          {/* Desktop Navigation */}
          <nav className="hidden md:flex items-center space-x-6">
            <Link
              href="/"
              className="text-gray-700 dark:text-gray-200 hover:text-primary dark:hover:text-primary-foreground"
            >
              Início
            </Link>
            <Link
              href="/hotels"
              className="text-gray-700 dark:text-gray-200 hover:text-primary dark:hover:text-primary-foreground"
            >
              Hotéis
            </Link>
            {isAuthenticated && (
              <Link
                href="/bookings"
                className="text-gray-700 dark:text-gray-200 hover:text-primary dark:hover:text-primary-foreground"
              >
                Minhas Reservas
              </Link>
            )}
            {user?.role === "ADMIN" || user?.role === "SUPER_ADMIN" ? (
              <Link
                href="/admin"
                className="text-gray-700 dark:text-gray-200 hover:text-primary dark:hover:text-primary-foreground"
              >
                Painel Admin
              </Link>
            ) : null}
          </nav>

          <div className="flex items-center space-x-4">
            <ThemeToggle />

            {isAuthenticated ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative rounded-full h-8 w-8 p-0">
                    <User className="h-5 w-5" />
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>Minha Conta</DropdownMenuLabel>
                  <DropdownMenuLabel className="font-normal text-sm text-muted-foreground">
                    {user?.email}
                  </DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <Link href="/account">
                    <DropdownMenuItem>
                      <User className="mr-2 h-4 w-4" />
                      <span>Perfil</span>
                    </DropdownMenuItem>
                  </Link>
                  <Link href="/bookings">
                    <DropdownMenuItem>
                      <BookOpen className="mr-2 h-4 w-4" />
                      <span>Minhas Reservas</span>
                    </DropdownMenuItem>
                  </Link>
                  {(user?.role === "ADMIN" || user?.role === "SUPER_ADMIN") && (
                    <Link href="/admin">
                      <DropdownMenuItem>
                        <Settings className="mr-2 h-4 w-4" />
                        <span>Painel Admin</span>
                      </DropdownMenuItem>
                    </Link>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={() => logout()}>
                    <LogOut className="mr-2 h-4 w-4" />
                    <span>Sair</span>
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <div className="flex items-center space-x-2">
                <Link href="/login">
                  <Button variant="ghost" size="sm">
                    Entrar
                  </Button>
                </Link>
                <Link href="/register">
                  <Button size="sm">Cadastrar</Button>
                </Link>
              </div>
            )}

            {/* Mobile Menu Button */}
            <button
              className="md:hidden text-gray-700 dark:text-gray-200"
              onClick={toggleMobileMenu}
              aria-label={mobileMenuOpen ? "Fechar menu" : "Abrir menu"}
            >
              {mobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
            </button>
          </div>
        </div>

        {/* Mobile Navigation */}
        {mobileMenuOpen && (
          <nav className="md:hidden mt-4 pb-4 space-y-4">
            <Link
              href="/"
              className="block text-gray-700 dark:text-gray-200 hover:text-primary dark:hover:text-primary-foreground py-2"
              onClick={() => setMobileMenuOpen(false)}
            >
              Início
            </Link>
            <Link
              href="/hotels"
              className="block text-gray-700 dark:text-gray-200 hover:text-primary dark:hover:text-primary-foreground py-2"
              onClick={() => setMobileMenuOpen(false)}
            >
              Hotéis
            </Link>
            {isAuthenticated && (
              <Link
                href="/bookings"
                className="block text-gray-700 dark:text-gray-200 hover:text-primary dark:hover:text-primary-foreground py-2"
                onClick={() => setMobileMenuOpen(false)}
              >
                Minhas Reservas
              </Link>
            )}
            {user?.role === "ADMIN" || user?.role === "SUPER_ADMIN" ? (
              <Link
                href="/admin"
                className="block text-gray-700 dark:text-gray-200 hover:text-primary dark:hover:text-primary-foreground py-2"
                onClick={() => setMobileMenuOpen(false)}
              >
                Painel Admin
              </Link>
            ) : null}
          </nav>
        )}
      </div>
    </header>
  )
}
