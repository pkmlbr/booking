"use client"

import { useState } from "react"
import Image from "next/image"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"
import { useRouter } from "next/navigation"

interface RecentSearch {
  id: string
  location: string
  image: string
  checkIn: Date
  checkOut: Date
  guests: number
}

export default function RecentSearches() {
  const router = useRouter()
  const [searches, setSearches] = useState<RecentSearch[]>([
    {
      id: "1",
      location: "Brasília",
      image: "/brasilia.png",
      checkIn: new Date(2023, 11, 15),
      checkOut: new Date(2023, 11, 18),
      guests: 2,
    },
    {
      id: "2",
      location: "São Paulo",
      image: "/sao-paulo.png",
      checkIn: new Date(2023, 11, 20),
      checkOut: new Date(2023, 11, 23),
      guests: 3,
    },
    {
      id: "3",
      location: "Rio de Janeiro",
      image: "/rio-de-janeiro-beach.png",
      checkIn: new Date(2023, 11, 25),
      checkOut: new Date(2023, 11, 30),
      guests: 2,
    },
  ])

  const handleSearchClick = (search: RecentSearch) => {
    const params = new URLSearchParams()
    params.append("location", search.location)
    params.append("checkIn", format(search.checkIn, "yyyy-MM-dd"))
    params.append("checkOut", format(search.checkOut, "yyyy-MM-dd"))
    params.append("adults", search.guests.toString())

    router.push(`/hotels?${params.toString()}`)
  }

  if (searches.length === 0) {
    return null
  }

  return (
    <div className="py-6">
      <h2 className="text-lg font-bold mb-4">Suas pesquisas recentes</h2>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
        {searches.map((search) => (
          <div
            key={search.id}
            className="border border-gray-200 rounded-lg overflow-hidden cursor-pointer"
            onClick={() => handleSearchClick(search)}
          >
            <div className="flex">
              <div className="relative w-24 h-24">
                <Image
                  src={search.image || `/placeholder.svg?height=100&width=100&query=${search.location}`}
                  alt={search.location}
                  fill
                  className="object-cover"
                />
              </div>
              <div className="p-3 flex-1">
                <h3 className="font-bold text-booking-blue-light">{search.location}</h3>
                <p className="text-sm text-gray-600">
                  {format(search.checkIn, "d MMM", { locale: ptBR })} -{" "}
                  {format(search.checkOut, "d MMM", { locale: ptBR })}
                </p>
                <p className="text-sm text-gray-600">
                  {search.guests} {search.guests === 1 ? "hóspede" : "hóspedes"}
                </p>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
