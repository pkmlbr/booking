"use client"

import { useState } from "react"
import Link from "next/link"
import { ChevronDown, ChevronUp } from "lucide-react"

interface FooterSection {
  title: string
  links: {
    name: string
    href: string
  }[]
}

export default function MobileFooter() {
  const [openSection, setOpenSection] = useState<string | null>(null)
  const currentYear = new Date().getFullYear()

  const footerSections: FooterSection[] = [
    {
      title: "Destinos",
      links: [
        { name: "Regiões", href: "/regions" },
        { name: "Cidades", href: "/cities" },
        { name: "Distritos", href: "/districts" },
        { name: "Aeroportos", href: "/airports" },
        { name: "Hotéis", href: "/hotels" },
        { name: "Pontos de interesse", href: "/landmarks" },
      ],
    },
    {
      title: "Acomodações",
      links: [
        { name: "Casas e apartamentos", href: "/homes" },
        { name: "Hotéis", href: "/hotels" },
        { name: "Resorts", href: "/resorts" },
        { name: "Pousadas", href: "/inns" },
        { name: "Hostels", href: "/hostels" },
        { name: "B&Bs", href: "/bnbs" },
      ],
    },
    {
      title: "Serviços e configurações",
      links: [
        { name: "Aluguel de carros", href: "/car-rental" },
        { name: "Busca de voos", href: "/flights" },
        { name: "Reservas de restaurantes", href: "/restaurants" },
        { name: "Agentes de viagem", href: "/travel-agents" },
      ],
    },
    {
      title: "Sobre",
      links: [
        { name: "Sobre a Booking.com", href: "/about" },
        { name: "Carreiras", href: "/careers" },
        { name: "Imprensa", href: "/press" },
        { name: "Relações com investidores", href: "/investors" },
        { name: "Termos e condições", href: "/terms" },
        { name: "Como trabalhamos", href: "/how-we-work" },
      ],
    },
    {
      title: "Ajuda",
      links: [
        { name: "Central de ajuda", href: "/help" },
        { name: "Suporte ao cliente", href: "/support" },
        { name: "FAQ", href: "/faq" },
        { name: "Configurações de cookies", href: "/cookie-settings" },
      ],
    },
  ]

  const toggleSection = (title: string) => {
    if (openSection === title) {
      setOpenSection(null)
    } else {
      setOpenSection(title)
    }
  }

  return (
    <footer className="mobile-footer">
      {footerSections.map((section) => (
        <div key={section.title} className="mobile-footer-section">
          <div className="mobile-footer-title" onClick={() => toggleSection(section.title)}>
            <span>{section.title}</span>
            {openSection === section.title ? <ChevronUp className="h-4 w-4" /> : <ChevronDown className="h-4 w-4" />}
          </div>

          {openSection === section.title && (
            <div className="mobile-footer-links">
              {section.links.map((link, index) => (
                <div key={index}>
                  <Link href={link.href} className="mobile-footer-link">
                    {link.name}
                  </Link>
                </div>
              ))}
            </div>
          )}
        </div>
      ))}

      <div className="mobile-footer-copyright">
        <p>Copyright &copy; {currentYear} Booking.com™. Todos os direitos reservados.</p>
      </div>
    </footer>
  )
}
