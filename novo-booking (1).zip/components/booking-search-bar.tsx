"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { format, addDays } from "date-fns"
import { ptBR } from "date-fns/locale"
import { Search, Calendar, Users, MapPin } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"

interface BookingSearchBarProps {
  initialLocation?: string
  initialCheckIn?: Date
  initialCheckOut?: Date
  initialAdults?: number
  initialChildren?: number
  initialRooms?: number
  className?: string
  variant?: "home" | "hotels"
}

export default function BookingSearchBar({
  initialLocation = "",
  initialCheckIn,
  initialCheckOut,
  initialAdults = 2,
  initialChildren = 0,
  initialRooms = 1,
  className = "",
  variant = "home",
}: BookingSearchBarProps) {
  const router = useRouter()
  const [location, setLocation] = useState(initialLocation)
  const [checkIn, setCheckIn] = useState<Date | undefined>(initialCheckIn || new Date())
  const [checkOut, setCheckOut] = useState<Date | undefined>(initialCheckOut || addDays(new Date(), 1))
  const [adults, setAdults] = useState(initialAdults || 2)
  const [children, setChildren] = useState(initialChildren || 0)
  const [rooms, setRooms] = useState(initialRooms || 1)
  const [isCheckInOpen, setIsCheckInOpen] = useState(false)
  const [isCheckOutOpen, setIsCheckOutOpen] = useState(false)
  const [isGuestsOpen, setIsGuestsOpen] = useState(false)

  // Atualizar estados quando as props mudarem
  useEffect(() => {
    setLocation(initialLocation || "")
    setCheckIn(initialCheckIn || new Date())
    setCheckOut(initialCheckOut || addDays(new Date(), 1))
    setAdults(initialAdults || 2)
    setChildren(initialChildren || 0)
    setRooms(initialRooms || 1)
  }, [initialLocation, initialCheckIn, initialCheckOut, initialAdults, initialChildren, initialRooms])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()

    const params = new URLSearchParams()

    if (location) params.append("location", location)
    if (checkIn) params.append("checkIn", format(checkIn, "yyyy-MM-dd"))
    if (checkOut) params.append("checkOut", format(checkOut, "yyyy-MM-dd"))
    if (adults > 0) params.append("adults", adults.toString())
    if (children > 0) params.append("children", children.toString())
    if (rooms > 0) params.append("rooms", rooms.toString())

    router.push(`/hotels?${params.toString()}`)
  }

  return (
    <div
      className={`${className} ${variant === "home" ? "bg-booking-blue p-4 rounded-md" : "bg-white shadow-md p-4 rounded-md"}`}
    >
      <form onSubmit={handleSearch} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-4 gap-2">
          <div className="md:col-span-1">
            <div className="relative">
              <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
                <MapPin className={`h-5 w-5 ${variant === "home" ? "text-white" : "text-gray-400"}`} />
              </div>
              <Input
                type="text"
                placeholder="Para onde você vai?"
                className={`pl-10 ${variant === "home" ? "bg-white text-black" : "bg-white"} h-12`}
                value={location}
                onChange={(e) => setLocation(e.target.value)}
              />
            </div>
          </div>

          <div className="md:col-span-1">
            <Popover open={isCheckInOpen} onOpenChange={setIsCheckInOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant={variant === "home" ? "secondary" : "outline"}
                  className="w-full justify-start text-left h-12"
                  onClick={() => setIsCheckInOpen(true)}
                >
                  <Calendar className="mr-2 h-4 w-4" />
                  {checkIn ? format(checkIn, "EEE, dd MMM", { locale: ptBR }) : <span>Check-in</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <CalendarComponent
                  mode="single"
                  selected={checkIn}
                  onSelect={(date) => {
                    setCheckIn(date)
                    setIsCheckInOpen(false)
                    if (date && (!checkOut || date >= checkOut)) {
                      // Se o check-in for depois do check-out, ajustar o check-out
                      const newCheckOut = new Date(date)
                      newCheckOut.setDate(newCheckOut.getDate() + 1)
                      setCheckOut(newCheckOut)
                    }
                  }}
                  disabled={(date) => date < new Date()}
                  locale={ptBR}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="md:col-span-1">
            <Popover open={isCheckOutOpen} onOpenChange={setIsCheckOutOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant={variant === "home" ? "secondary" : "outline"}
                  className="w-full justify-start text-left h-12"
                  onClick={() => setIsCheckOutOpen(true)}
                >
                  <Calendar className="mr-2 h-4 w-4" />
                  {checkOut ? format(checkOut, "EEE, dd MMM", { locale: ptBR }) : <span>Check-out</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <CalendarComponent
                  mode="single"
                  selected={checkOut}
                  onSelect={(date) => {
                    setCheckOut(date)
                    setIsCheckOutOpen(false)
                  }}
                  disabled={(date) => date < new Date() || (checkIn ? date <= checkIn : false)}
                  locale={ptBR}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>

          <div className="md:col-span-1">
            <Popover open={isGuestsOpen} onOpenChange={setIsGuestsOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant={variant === "home" ? "secondary" : "outline"}
                  className="w-full justify-start text-left h-12"
                  onClick={() => setIsGuestsOpen(true)}
                >
                  <Users className="mr-2 h-4 w-4" />
                  <span>
                    {adults} {adults === 1 ? "adulto" : "adultos"}
                    {children > 0 ? `, ${children} ${children === 1 ? "criança" : "crianças"}` : ""}
                    {rooms > 1 ? `, ${rooms} quartos` : ""}
                  </span>
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-80" align="start">
                <div className="space-y-4 p-2">
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Adultos</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => setAdults(Math.max(1, adults - 1))}
                        disabled={adults <= 1}
                      >
                        -
                      </Button>
                      <span className="w-8 text-center">{adults}</span>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => setAdults(adults + 1)}
                        disabled={adults + children >= 20}
                      >
                        +
                      </Button>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Crianças</p>
                      <p className="text-sm text-muted-foreground">0-17 anos</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => setChildren(Math.max(0, children - 1))}
                        disabled={children <= 0}
                      >
                        -
                      </Button>
                      <span className="w-8 text-center">{children}</span>
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => setChildren(children + 1)}
                        disabled={adults + children >= 20}
                      >
                        +
                      </Button>
                    </div>
                  </div>
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="font-medium">Quartos</p>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Button
                        variant="outline"
                        size="icon"
                        onClick={() => setRooms(Math.max(1, rooms - 1))}
                        disabled={rooms <= 1}
                      >
                        -
                      </Button>
                      <span className="w-8 text-center">{rooms}</span>
                      <Button variant="outline" size="icon" onClick={() => setRooms(rooms + 1)} disabled={rooms >= 10}>
                        +
                      </Button>
                    </div>
                  </div>
                  <Button className="w-full mt-2" onClick={() => setIsGuestsOpen(false)}>
                    Concluído
                  </Button>
                </div>
              </PopoverContent>
            </Popover>
          </div>
        </div>

        <div className="flex justify-center">
          <Button
            type="submit"
            className={`${variant === "home" ? "bg-booking-blue-light" : "bg-booking-blue"} hover:bg-opacity-90 text-white font-bold py-3 px-8 text-lg`}
          >
            <Search className="mr-2 h-5 w-5" />
            Pesquisar
          </Button>
        </div>
      </form>
    </div>
  )
}
