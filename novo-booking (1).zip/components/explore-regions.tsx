"use client"

import { useState } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"

interface Region {
  id: number
  name: string
  image: string
  cities: string[]
  slug: string
}

export default function ExploreRegions() {
  const router = useRouter()
  const [regions] = useState<Region[]>([
    {
      id: 1,
      name: "Nordeste",
      image: "/nordeste.png",
      cities: ["Salvador", "Fortaleza", "Recife", "Natal", "João Pessoa"],
      slug: "northeast",
    },
    {
      id: 2,
      name: "Sudeste",
      image: "/sudeste.png",
      cities: ["São Paulo", "Rio de Janeiro", "Belo Horizonte", "Vitória"],
      slug: "southeast",
    },
    {
      id: 3,
      name: "Sul",
      image: "/sul.png",
      cities: ["Florianópolis", "Gramado", "Curitiba", "Porto Alegre"],
      slug: "south",
    },
    {
      id: 4,
      name: "Centro-Oeste",
      image: "/centro-oeste.png",
      cities: ["Brasília", "Goiânia", "Cuiabá", "Campo Grande"],
      slug: "midwest",
    },
    {
      id: 5,
      name: "Norte",
      image: "/norte.png",
      cities: ["Manaus", "Belém", "Palmas", "Rio Branco"],
      slug: "north",
    },
  ])

  const handleRegionClick = (region: Region) => {
    router.push(`/hotels?region=${region.slug}`)
  }

  return (
    <div className="py-8">
      <h2 className="text-2xl font-bold mb-6">Conheça o Brasil</h2>

      <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-5 gap-4">
        {regions.map((region) => (
          <div key={region.id} className="cursor-pointer" onClick={() => handleRegionClick(region)}>
            <div className="relative h-32 rounded-lg overflow-hidden mb-2">
              <Image
                src={region.image || `/placeholder.svg?height=150&width=150&query=${region.name}`}
                alt={region.name}
                fill
                className="object-cover transition-transform duration-300 hover:scale-110"
              />
            </div>
            <h3 className="font-bold">{region.name}</h3>
            <p className="text-sm text-gray-600 truncate">
              {region.cities.slice(0, 3).join(", ")}
              {region.cities.length > 3 ? " e mais" : ""}
            </p>
          </div>
        ))}
      </div>
    </div>
  )
}
