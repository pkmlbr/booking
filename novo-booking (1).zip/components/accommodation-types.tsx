"use client"

import { useState } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"

interface AccommodationType {
  id: number
  name: string
  image: string
  count: number
  type: string
}

export default function AccommodationTypes() {
  const router = useRouter()
  const [types] = useState<AccommodationType[]>([
    {
      id: 1,
      name: "Hotéis",
      image: "/hotel-type.png",
      count: 865,
      type: "hotel",
    },
    {
      id: 2,
      name: "Apartamentos",
      image: "/apartment-type.png",
      count: 432,
      type: "apartment",
    },
    {
      id: 3,
      name: "Casas de temporada",
      image: "/vacation-home-type.png",
      count: 321,
      type: "vacation-home",
    },
    {
      id: 4,
      name: "Pousadas",
      image: "/inn-type.png",
      count: 267,
      type: "inn",
    },
  ])

  const handleTypeClick = (type: AccommodationType) => {
    router.push(`/hotels?type=${type.type}`)
  }

  return (
    <div className="py-8">
      <h2 className="text-2xl font-bold mb-6">Pesquise por tipo de acomodação</h2>

      <div className="grid grid-cols-2 md:grid-cols-4 gap-4">
        {types.map((type) => (
          <div key={type.id} className="cursor-pointer" onClick={() => handleTypeClick(type)}>
            <div className="relative h-48 rounded-lg overflow-hidden mb-2">
              <Image
                src={type.image || `/placeholder.svg?height=200&width=200&query=${type.name}`}
                alt={type.name}
                fill
                className="object-cover transition-transform duration-300 hover:scale-110"
              />
            </div>
            <h3 className="font-bold">{type.name}</h3>
            <p className="text-sm text-gray-600">{type.count} propriedades</p>
          </div>
        ))}
      </div>
    </div>
  )
}
