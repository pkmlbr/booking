"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"
import { Heart } from "lucide-react"

interface Accommodation {
  id: string
  name: string
  location: string
  image: string
  price: number
  rating: number
}

export default function MobileExclusiveAccommodations() {
  const router = useRouter()
  const [accommodations] = useState<Accommodation[]>([
    {
      id: "1",
      name: "Pousada Rio Vista",
      location: "Rio de Janeiro",
      image: "/pousada-rio.png",
      price: 1200,
      rating: 9.2,
    },
    {
      id: "2",
      name: "Iate Yacht",
      location: "Angra dos Reis",
      image: "/iate-yacht.png",
      price: 2500,
      rating: 9.6,
    },
    {
      id: "3",
      name: "Pousada Inacreditável",
      location: "Campos do Jordão",
      image: "/pousada-inacreditavel.png",
      price: 1800,
      rating: 9.4,
    },
  ])

  const handleAccommodationClick = (accommodation: Accommodation) => {
    router.push(`/hotels/${accommodation.id}`)
  }

  const toggleFavorite = (e: React.MouseEvent, id: string) => {
    e.stopPropagation()
    // Implementar lógica de favoritos
    console.log(`Toggle favorite for ${id}`)
  }

  const getRatingColor = (rating: number) => {
    if (rating >= 9.0) return "bg-[#004cb8]"
    if (rating >= 8.0) return "bg-[#0a6a4a]"
    if (rating >= 7.0) return "bg-[#6a8a00]"
    if (rating >= 6.0) return "bg-[#c26b00]"
    return "bg-[#767676]"
  }

  return (
    <div className="py-4">
      <h2 className="mobile-section-title">Fique em uma acomodação exclusiva</h2>

      <div className="scroll-container">
        {accommodations.map((accommodation) => (
          <div
            key={accommodation.id}
            className="exclusive-accommodation-card"
            onClick={() => handleAccommodationClick(accommodation)}
          >
            <div className="relative h-32 w-64">
              <Image
                src={accommodation.image || `/placeholder.svg?height=150&width=250&query=${accommodation.name}`}
                alt={accommodation.name}
                fill
                className="object-cover"
              />
              <button
                className="absolute top-2 right-2 bg-white rounded-full p-1"
                onClick={(e) => toggleFavorite(e, accommodation.id)}
              >
                <Heart className="h-4 w-4 text-gray-500" />
              </button>
            </div>
            <div className="p-3">
              <h3 className="font-bold text-booking-blue-light text-sm">{accommodation.name}</h3>
              <p className="text-xs text-gray-600 mb-1">{accommodation.location}</p>
              <div className="flex justify-between items-center">
                <p className="font-bold">R$ {accommodation.price}</p>
                <div
                  className={`${getRatingColor(accommodation.rating)} text-white font-bold px-1 py-0.5 rounded text-xs`}
                >
                  {accommodation.rating}
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
