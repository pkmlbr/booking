"use client"

import { useState, useEffect } from "react"
import { useRouter, useSearchParams } from "next/navigation"
import { Slider } from "@/components/ui/slider"
import { Checkbox } from "@/components/ui/checkbox"
import { Label } from "@/components/ui/label"
import { Button } from "@/components/ui/button"
import { Star } from "lucide-react"

interface HotelFiltersProps {
  location?: string
  checkIn?: string
  checkOut?: string
}

export default function HotelFilters({ location, checkIn, checkOut }: HotelFiltersProps) {
  const router = useRouter()
  const searchParams = useSearchParams()

  const [priceRange, setPriceRange] = useState([0, 1000])
  const [starRating, setStarRating] = useState<number[]>([])
  const [propertyTypes, setPropertyTypes] = useState<string[]>([])
  const [facilities, setFacilities] = useState<string[]>([])

  // Inicializar filtros a partir dos parâmetros de URL
  useEffect(() => {
    const params = new URLSearchParams(searchParams.toString())

    // Preço
    const minPrice = params.get("minPrice")
    const maxPrice = params.get("maxPrice")
    if (minPrice && maxPrice) {
      setPriceRange([Number(minPrice), Number(maxPrice)])
    }

    // Estrelas
    const stars = params.get("stars")
    if (stars) {
      setStarRating(stars.split(",").map(Number))
    }

    // Tipos de propriedade
    const types = params.get("types")
    if (types) {
      setPropertyTypes(types.split(","))
    }

    // Facilidades
    const facilitiesParam = params.get("facilities")
    if (facilitiesParam) {
      setFacilities(facilitiesParam.split(","))
    }
  }, [searchParams])

  const applyFilters = () => {
    const params = new URLSearchParams(searchParams.toString())

    // Preço
    params.set("minPrice", priceRange[0].toString())
    params.set("maxPrice", priceRange[1].toString())

    // Estrelas
    if (starRating.length > 0) {
      params.set("stars", starRating.join(","))
    } else {
      params.delete("stars")
    }

    // Tipos de propriedade
    if (propertyTypes.length > 0) {
      params.set("types", propertyTypes.join(","))
    } else {
      params.delete("types")
    }

    // Facilidades
    if (facilities.length > 0) {
      params.set("facilities", facilities.join(","))
    } else {
      params.delete("facilities")
    }

    router.push(`/hotels?${params.toString()}`)
  }

  const resetFilters = () => {
    const params = new URLSearchParams()

    // Manter apenas os parâmetros básicos
    if (location) params.set("location", location)
    if (checkIn) params.set("checkIn", checkIn)
    if (checkOut) params.set("checkOut", checkOut)

    setPriceRange([0, 1000])
    setStarRating([])
    setPropertyTypes([])
    setFacilities([])

    router.push(`/hotels?${params.toString()}`)
  }

  const toggleStarRating = (star: number) => {
    setStarRating((prev) => (prev.includes(star) ? prev.filter((s) => s !== star) : [...prev, star]))
  }

  const togglePropertyType = (type: string) => {
    setPropertyTypes((prev) => (prev.includes(type) ? prev.filter((t) => t !== type) : [...prev, type]))
  }

  const toggleFacility = (facility: string) => {
    setFacilities((prev) => (prev.includes(facility) ? prev.filter((f) => f !== facility) : [...prev, facility]))
  }

  return (
    <div className="bg-white p-4 rounded-lg border border-gray-200">
      <h2 className="text-lg font-bold mb-4">Filtros</h2>

      {/* Preço */}
      <div className="mb-6">
        <h3 className="font-medium mb-3">Faixa de preço (por noite)</h3>
        <Slider
          defaultValue={priceRange}
          min={0}
          max={2000}
          step={50}
          value={priceRange}
          onValueChange={setPriceRange}
          className="mb-2"
        />
        <div className="flex justify-between text-sm">
          <span>R$ {priceRange[0]}</span>
          <span>R$ {priceRange[1]}</span>
        </div>
      </div>

      {/* Classificação por estrelas */}
      <div className="mb-6">
        <h3 className="font-medium mb-3">Classificação por estrelas</h3>
        <div className="space-y-2">
          {[5, 4, 3, 2, 1].map((star) => (
            <div key={star} className="flex items-center">
              <Checkbox
                id={`star-${star}`}
                checked={starRating.includes(star)}
                onCheckedChange={() => toggleStarRating(star)}
              />
              <Label htmlFor={`star-${star}`} className="ml-2 flex items-center">
                {Array.from({ length: star }).map((_, i) => (
                  <Star key={i} className="h-4 w-4 fill-yellow-400 text-yellow-400" />
                ))}
              </Label>
            </div>
          ))}
        </div>
      </div>

      {/* Tipo de propriedade */}
      <div className="mb-6">
        <h3 className="font-medium mb-3">Tipo de propriedade</h3>
        <div className="space-y-2">
          {[
            { id: "hotel", label: "Hotel" },
            { id: "apartment", label: "Apartamento" },
            { id: "resort", label: "Resort" },
            { id: "inn", label: "Pousada" },
            { id: "hostel", label: "Hostel" },
          ].map((type) => (
            <div key={type.id} className="flex items-center">
              <Checkbox
                id={`type-${type.id}`}
                checked={propertyTypes.includes(type.id)}
                onCheckedChange={() => togglePropertyType(type.id)}
              />
              <Label htmlFor={`type-${type.id}`} className="ml-2">
                {type.label}
              </Label>
            </div>
          ))}
        </div>
      </div>

      {/* Comodidades */}
      <div className="mb-6">
        <h3 className="font-medium mb-3">Comodidades</h3>
        <div className="space-y-2">
          {[
            { id: "wifi", label: "Wi-Fi" },
            { id: "parking", label: "Estacionamento" },
            { id: "pool", label: "Piscina" },
            { id: "ac", label: "Ar-condicionado" },
            { id: "breakfast", label: "Café da manhã" },
            { id: "gym", label: "Academia" },
          ].map((facility) => (
            <div key={facility.id} className="flex items-center">
              <Checkbox
                id={`facility-${facility.id}`}
                checked={facilities.includes(facility.id)}
                onCheckedChange={() => toggleFacility(facility.id)}
              />
              <Label htmlFor={`facility-${facility.id}`} className="ml-2">
                {facility.label}
              </Label>
            </div>
          ))}
        </div>
      </div>

      {/* Botões */}
      <div className="flex flex-col space-y-2">
        <Button onClick={applyFilters} className="bg-booking-blue w-full">
          Aplicar filtros
        </Button>
        <Button variant="outline" onClick={resetFilters} className="w-full">
          Limpar filtros
        </Button>
      </div>
    </div>
  )
}
