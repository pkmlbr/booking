export default function MobilePopularDestinations() {
  const destinations = [
    "Capitais brasileiras",
    "Cidades internacionais",
    "Regiões",
    "Países",
    "Aeroportos",
    "Pontos de interesse",
    "Hotéis",
  ]

  const cities = [
    "Rio de Janeiro",
    "São Paulo",
    "Salvador",
    "Fortaleza",
    "Brasília",
    "Recife",
    "Porto Alegre",
    "Belo Horizonte",
    "Curitiba",
    "Manaus",
    "Florianópolis",
    "Natal",
    "Porto Seguro",
    "Gramado",
    "Foz do Iguaçu",
  ]

  return (
    <div className="py-4">
      <h2 className="mobile-section-title">Popular entre viajantes do Brasil</h2>

      <div className="scroll-container mb-4">
        {destinations.map((destination, index) => (
          <div key={index} className="bg-gray-100 rounded-full px-3 py-1 text-sm whitespace-nowrap">
            {destination}
          </div>
        ))}
      </div>

      <div className="px-4 grid grid-cols-2 gap-2">
        {cities.map((city, index) => (
          <div key={index} className="text-sm text-booking-blue-light py-1">
            {city}
          </div>
        ))}
      </div>
    </div>
  )
}
