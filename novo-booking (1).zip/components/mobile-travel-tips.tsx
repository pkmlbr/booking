"use client"

import type React from "react"

import { useState } from "react"
import Image from "next/image"
import { Button } from "@/components/ui/button"

export default function MobileTravelTips() {
  const [email, setEmail] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Implementar lógica de inscrição na newsletter
    alert(`Email ${email} inscrito com sucesso!`)
    setEmail("")
  }

  return (
    <div className="py-4 px-4">
      <div className="bg-blue-600 text-white p-4 rounded-lg flex items-start mb-4">
        <div className="flex-1">
          <h2 className="font-bold mb-1">Reserve agora, fique mais tarde</h2>
          <p className="text-sm mb-2">Milhares de acomodações com cancelamento grátis</p>
          <Button className="bg-booking-yellow text-black hover:bg-yellow-400">Explorar</Button>
        </div>
        <div className="ml-2">
          <Image
            src="/travel-illustration.png"
            alt="Ilustração de viagem"
            width={80}
            height={80}
            className="object-contain"
          />
        </div>
      </div>

      <div className="bg-blue-50 p-4 rounded-lg">
        <h2 className="font-bold mb-2">Viaje mais, gaste menos</h2>
        <p className="text-sm mb-2">Receba ofertas exclusivas e dicas de viagem:</p>
        <form onSubmit={handleSubmit} className="space-y-2">
          <input
            type="email"
            placeholder="Seu endereço de e-mail"
            className="w-full p-2 rounded border"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            required
          />
          <Button type="submit" className="w-full bg-booking-blue">
            Inscrever-se
          </Button>
        </form>
      </div>
    </div>
  )
}
