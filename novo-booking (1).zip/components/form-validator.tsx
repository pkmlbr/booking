"use client"

import { useState, type FormEvent, type ReactNode } from "react"

interface FormValidatorProps {
  children: ReactNode | ((props: FormValidatorChildProps) => ReactNode)
  onSubmit: (data: Record<string, any>) => void | Promise<void>
  initialValues?: Record<string, any>
  validationRules?: Record<string, (value: any) => string | null>
}

interface FormValidatorChildProps {
  values: Record<string, any>
  errors: Record<string, string | null>
  handleChange: (name: string, value: any) => void
  handleSubmit: (e: FormEvent) => void
  isSubmitting: boolean
  touched: Record<string, boolean>
  setFieldTouched: (name: string) => void
}

export default function FormValidator({
  children,
  onSubmit,
  initialValues = {},
  validationRules = {},
}: FormValidatorProps) {
  const [values, setValues] = useState(initialValues)
  const [errors, setErrors] = useState<Record<string, string | null>>({})
  const [touched, setTouched] = useState<Record<string, boolean>>({})
  const [isSubmitting, setIsSubmitting] = useState(false)

  const validateField = (name: string, value: any): string | null => {
    if (!validationRules[name]) return null
    return validationRules[name](value)
  }

  const validateForm = (): boolean => {
    const newErrors: Record<string, string | null> = {}
    let isValid = true

    Object.keys(validationRules).forEach((field) => {
      const error = validateField(field, values[field])
      newErrors[field] = error

      if (error) {
        isValid = false
      }
    })

    setErrors(newErrors)
    return isValid
  }

  const handleChange = (name: string, value: any) => {
    setValues((prev) => ({ ...prev, [name]: value }))

    if (touched[name]) {
      const error = validateField(name, value)
      setErrors((prev) => ({ ...prev, [name]: error }))
    }
  }

  const setFieldTouched = (name: string) => {
    if (!touched[name]) {
      setTouched((prev) => ({ ...prev, [name]: true }))
      const error = validateField(name, values[name])
      setErrors((prev) => ({ ...prev, [name]: error }))
    }
  }

  const handleSubmit = async (e: FormEvent) => {
    e.preventDefault()

    // Marcar todos os campos como tocados
    const allTouched = Object.keys(validationRules).reduce((acc, field) => ({ ...acc, [field]: true }), {})
    setTouched(allTouched)

    // Validar o formulário
    const isValid = validateForm()

    if (!isValid) return

    setIsSubmitting(true)

    try {
      await onSubmit(values)
    } catch (error) {
      console.error("Erro ao enviar formulário:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const childProps: FormValidatorChildProps = {
    values,
    errors,
    handleChange,
    handleSubmit,
    isSubmitting,
    touched,
    setFieldTouched,
  }

  return typeof children === "function" ? children(childProps) : children
}
