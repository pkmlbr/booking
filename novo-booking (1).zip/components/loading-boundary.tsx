"use client"

import { Suspense, type ReactNode } from "react"
import { Skeleton } from "@/components/ui/skeleton"

interface LoadingBoundaryProps {
  children: ReactNode
  fallback?: ReactNode
}

export default function LoadingBoundary({
  children,
  fallback = <Skeleton className="h-40 w-full" />,
}: LoadingBoundaryProps) {
  return <Suspense fallback={fallback}>{children}</Suspense>
}
