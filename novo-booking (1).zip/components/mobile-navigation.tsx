"use client"

import Link from "next/link"
import { Home, Search, Heart, User, Menu } from "lucide-react"
import { usePathname } from "next/navigation"

export default function MobileNavigation() {
  const pathname = usePathname()

  return (
    <nav className="mobile-nav">
      <Link href="/" className={`mobile-nav-item ${pathname === "/" ? "active" : ""}`}>
        <Home className="mobile-nav-icon" />
        <span>Início</span>
      </Link>
      <Link href="/search" className={`mobile-nav-item ${pathname === "/search" ? "active" : ""}`}>
        <Search className="mobile-nav-icon" />
        <span>Buscar</span>
      </Link>
      <Link href="/saved" className={`mobile-nav-item ${pathname === "/saved" ? "active" : ""}`}>
        <Heart className="mobile-nav-icon" />
        <span>Salvos</span>
      </Link>
      <Link href="/bookings" className={`mobile-nav-item ${pathname === "/bookings" ? "active" : ""}`}>
        <Menu className="mobile-nav-icon" />
        <span>Reservas</span>
      </Link>
      <Link href="/account" className={`mobile-nav-item ${pathname === "/account" ? "active" : ""}`}>
        <User className="mobile-nav-icon" />
        <span>Conta</span>
      </Link>
    </nav>
  )
}
