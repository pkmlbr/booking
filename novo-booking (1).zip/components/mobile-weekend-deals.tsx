"use client"

import { useState } from "react"
import Image from "next/image"
import { useRouter } from "next/navigation"

interface Deal {
  id: string
  name: string
  location: string
  image: string
  price: number
  originalPrice: number
  rating: number
  reviewCount: number
}

export default function MobileWeekendDeals() {
  const router = useRouter()
  const [deals] = useState<Deal[]>([
    {
      id: "1",
      name: "Piscina Olímpica - Casa R$1000",
      location: "Brasília",
      image: "/pool-house.png",
      price: 1000,
      originalPrice: 1200,
      rating: 8.6,
      reviewCount: 123,
    },
    {
      id: "2",
      name: "Hotel Brasil 21",
      location: "Brasília",
      image: "/hotel-brasil.png",
      price: 850,
      originalPrice: 950,
      rating: 9.2,
      reviewCount: 456,
    },
    {
      id: "3",
      name: "Pousada Recife da Serra",
      location: "Recife",
      image: "/pousada-recife.png",
      price: 750,
      originalPrice: 900,
      rating: 8.8,
      reviewCount: 234,
    },
    {
      id: "4",
      name: "Flat Residence Prime",
      location: "São Paulo",
      image: "/flat-residence.png",
      price: 950,
      originalPrice: 1100,
      rating: 9.0,
      reviewCount: 345,
    },
  ])

  const handleDealClick = (deal: Deal) => {
    router.push(`/hotels/${deal.id}`)
  }

  const getRatingColor = (rating: number) => {
    if (rating >= 9.0) return "bg-[#004cb8]"
    if (rating >= 8.0) return "bg-[#0a6a4a]"
    if (rating >= 7.0) return "bg-[#6a8a00]"
    if (rating >= 6.0) return "bg-[#c26b00]"
    return "bg-[#767676]"
  }

  return (
    <div className="py-4">
      <h2 className="mobile-section-title">Ofertas para o fim de semana</h2>

      <div className="scroll-container">
        {deals.map((deal) => (
          <div key={deal.id} className="weekend-deal-card" onClick={() => handleDealClick(deal)}>
            <div className="relative h-32 w-64">
              <Image
                src={deal.image || `/placeholder.svg?height=150&width=250&query=${deal.name}`}
                alt={deal.name}
                fill
                className="object-cover"
              />
            </div>
            <div className="p-3">
              <h3 className="font-bold text-booking-blue-light text-sm truncate">{deal.name}</h3>
              <p className="text-xs text-gray-600 mb-1">{deal.location}</p>
              <div className="flex justify-between items-center">
                <div>
                  <p className="text-xs text-gray-500 line-through">R$ {deal.originalPrice}</p>
                  <p className="font-bold">R$ {deal.price}</p>
                </div>
                <div className="flex items-center">
                  <div
                    className={`${getRatingColor(deal.rating)} text-white font-bold px-1 py-0.5 rounded text-xs mr-1`}
                  >
                    {deal.rating}
                  </div>
                  <span className="text-xs text-gray-500">{deal.reviewCount}</span>
                </div>
              </div>
            </div>
          </div>
        ))}
      </div>
    </div>
  )
}
