"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter } from "next/navigation"
import { Search, Calendar, Users } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar as CalendarComponent } from "@/components/ui/calendar"
import { format } from "date-fns"
import { ptBR } from "date-fns/locale"

interface SearchBarProps {
  initialLocation?: string
  initialCheckIn?: Date
  initialCheckOut?: Date
  initialAdults?: number
  initialChildren?: number
}

export default function SearchBar({
  initialLocation = "",
  initialCheckIn,
  initialCheckOut,
  initialAdults = 2,
  initialChildren = 0,
}: SearchBarProps) {
  const router = useRouter()
  const [location, setLocation] = useState(initialLocation)
  const [checkIn, setCheckIn] = useState<Date | undefined>(initialCheckIn)
  const [checkOut, setCheckOut] = useState<Date | undefined>(initialCheckOut)
  const [adults, setAdults] = useState(initialAdults || 2)
  const [children, setChildren] = useState(initialChildren || 0)
  const [isCheckInOpen, setIsCheckInOpen] = useState(false)
  const [isCheckOutOpen, setIsCheckOutOpen] = useState(false)
  const [isGuestsOpen, setIsGuestsOpen] = useState(false)

  // Atualizar estados quando as props mudarem
  useEffect(() => {
    setLocation(initialLocation || "")
    setCheckIn(initialCheckIn)
    setCheckOut(initialCheckOut)
    setAdults(initialAdults || 2)
    setChildren(initialChildren || 0)
  }, [initialLocation, initialCheckIn, initialCheckOut, initialAdults, initialChildren])

  const handleSearch = (e: React.FormEvent) => {
    e.preventDefault()

    const params = new URLSearchParams()

    if (location) params.append("location", location)
    if (checkIn) params.append("checkIn", format(checkIn, "yyyy-MM-dd"))
    if (checkOut) params.append("checkOut", format(checkOut, "yyyy-MM-dd"))
    if (adults > 0) params.append("adults", adults.toString())
    if (children > 0) params.append("children", children.toString())

    router.push(`/hotels?${params.toString()}`)
  }

  return (
    <div className="bg-white dark:bg-gray-800 rounded-lg shadow-md p-4 md:p-6 search-bar">
      <form onSubmit={handleSearch} className="space-y-4 md:space-y-0 md:flex md:space-x-4">
        <div className="flex-1">
          <Label htmlFor="location" className="sr-only">
            Destino
          </Label>
          <div className="relative">
            <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-400" size={18} />
            <Input
              id="location"
              type="text"
              placeholder="Para onde você vai?"
              className="pl-10"
              value={location}
              onChange={(e) => setLocation(e.target.value)}
            />
          </div>
        </div>

        <div className="grid grid-cols-2 gap-4 md:w-1/3">
          <div>
            <Popover open={isCheckInOpen} onOpenChange={setIsCheckInOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="w-full justify-start text-left font-normal"
                  onClick={() => setIsCheckInOpen(true)}
                >
                  <Calendar className="mr-2 h-4 w-4" />
                  {checkIn ? format(checkIn, "dd/MM/yyyy") : <span>Check-in</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <CalendarComponent
                  mode="single"
                  selected={checkIn}
                  onSelect={(date) => {
                    setCheckIn(date)
                    setIsCheckInOpen(false)
                    if (date && (!checkOut || date > checkOut)) {
                      // Se o check-in for depois do check-out, ajustar o check-out
                      const newCheckOut = new Date(date)
                      newCheckOut.setDate(newCheckOut.getDate() + 1)
                      setCheckOut(newCheckOut)
                    }
                  }}
                  disabled={(date) => date < new Date()}
                  locale={ptBR}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>

          <div>
            <Popover open={isCheckOutOpen} onOpenChange={setIsCheckOutOpen}>
              <PopoverTrigger asChild>
                <Button
                  variant="outline"
                  className="w-full justify-start text-left font-normal"
                  onClick={() => setIsCheckOutOpen(true)}
                >
                  <Calendar className="mr-2 h-4 w-4" />
                  {checkOut ? format(checkOut, "dd/MM/yyyy") : <span>Check-out</span>}
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0" align="start">
                <CalendarComponent
                  mode="single"
                  selected={checkOut}
                  onSelect={(date) => {
                    setCheckOut(date)
                    setIsCheckOutOpen(false)
                  }}
                  disabled={(date) => date < new Date() || (checkIn ? date <= checkIn : false)}
                  locale={ptBR}
                  initialFocus
                />
              </PopoverContent>
            </Popover>
          </div>
        </div>

        <div className="md:w-1/6">
          <Popover open={isGuestsOpen} onOpenChange={setIsGuestsOpen}>
            <PopoverTrigger asChild>
              <Button
                variant="outline"
                className="w-full justify-start text-left font-normal"
                onClick={() => setIsGuestsOpen(true)}
              >
                <Users className="mr-2 h-4 w-4" />
                <span>
                  {adults + children} {adults + children === 1 ? "hóspede" : "hóspedes"}
                </span>
              </Button>
            </PopoverTrigger>
            <PopoverContent className="w-80" align="start">
              <div className="space-y-4 p-2">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Adultos</p>
                    <p className="text-sm text-muted-foreground">Idade 13+</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setAdults(Math.max(1, adults - 1))}
                      disabled={adults <= 1}
                    >
                      -
                    </Button>
                    <span className="w-8 text-center">{adults}</span>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setAdults(adults + 1)}
                      disabled={adults + children >= 10}
                    >
                      +
                    </Button>
                  </div>
                </div>
                <div className="flex items-center justify-between">
                  <div>
                    <p className="font-medium">Crianças</p>
                    <p className="text-sm text-muted-foreground">Idade 0-12</p>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setChildren(Math.max(0, children - 1))}
                      disabled={children <= 0}
                    >
                      -
                    </Button>
                    <span className="w-8 text-center">{children}</span>
                    <Button
                      variant="outline"
                      size="icon"
                      onClick={() => setChildren(children + 1)}
                      disabled={adults + children >= 10}
                    >
                      +
                    </Button>
                  </div>
                </div>
                <Button className="w-full mt-2" onClick={() => setIsGuestsOpen(false)}>
                  Aplicar
                </Button>
              </div>
            </PopoverContent>
          </Popover>
        </div>

        <div className="md:w-auto">
          <Button type="submit" className="w-full">
            <Search className="mr-2 h-4 w-4" />
            Buscar
          </Button>
        </div>
      </form>
    </div>
  )
}
