"use client"

import type React from "react"

import { useState, useRef } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Upload, X, Loader2 } from "lucide-react"
import Image from "next/image"

interface ImageUploadProps {
  onUpload: (url: string) => void
  maxSizeMB?: number
  accept?: string
  label?: string
  className?: string
}

export default function ImageUpload({
  onUpload,
  maxSizeMB = 5,
  accept = "image/jpeg, image/png, image/webp",
  label = "Enviar imagem",
  className = "",
}: ImageUploadProps) {
  const [preview, setPreview] = useState<string | null>(null)
  const [isUploading, setIsUploading] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const inputRef = useRef<HTMLInputElement>(null)

  const maxSizeBytes = maxSizeMB * 1024 * 1024

  const handleFileChange = async (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0]

    if (!file) return

    // Validar tamanho
    if (file.size > maxSizeBytes) {
      setError(`A imagem deve ter no máximo ${maxSizeMB}MB`)
      return
    }

    // Validar tipo
    if (!file.type.startsWith("image/")) {
      setError("O arquivo deve ser uma imagem")
      return
    }

    setError(null)
    setIsUploading(true)

    try {
      // Criar preview
      const reader = new FileReader()
      reader.onload = (e) => {
        setPreview(e.target?.result as string)
      }
      reader.readAsDataURL(file)

      // Enviar para otimização
      const formData = new FormData()
      formData.append("image", file)
      formData.append("quality", "80")
      formData.append("format", "webp")

      const response = await fetch("/api/optimize-image", {
        method: "POST",
        body: formData,
      })

      if (!response.ok) {
        throw new Error("Falha ao otimizar a imagem")
      }

      const blob = await response.blob()
      const url = URL.createObjectURL(blob)

      onUpload(url)
    } catch (err) {
      setError("Erro ao enviar imagem. Tente novamente.")
      console.error("Erro ao enviar imagem:", err)
    } finally {
      setIsUploading(false)
    }
  }

  const handleRemove = () => {
    setPreview(null)
    if (inputRef.current) {
      inputRef.current.value = ""
    }
  }

  return (
    <div className={className}>
      <Label htmlFor="image-upload">{label}</Label>

      {!preview ? (
        <div className="mt-2">
          <div className="border-2 border-dashed border-gray-300 dark:border-gray-700 rounded-lg p-6 text-center">
            <Input
              id="image-upload"
              type="file"
              accept={accept}
              onChange={handleFileChange}
              className="hidden"
              ref={inputRef}
              disabled={isUploading}
            />

            <Button
              type="button"
              variant="outline"
              onClick={() => inputRef.current?.click()}
              disabled={isUploading}
              className="w-full h-32 flex flex-col items-center justify-center gap-2"
            >
              {isUploading ? (
                <>
                  <Loader2 className="h-8 w-8 animate-spin" />
                  <span>Enviando...</span>
                </>
              ) : (
                <>
                  <Upload className="h-8 w-8" />
                  <span>Clique para selecionar uma imagem</span>
                  <span className="text-xs text-muted-foreground">ou arraste e solte aqui</span>
                </>
              )}
            </Button>
          </div>

          {error && <p className="text-sm text-destructive mt-2">{error}</p>}
        </div>
      ) : (
        <div className="mt-2 relative">
          <div className="relative h-48 rounded-lg overflow-hidden">
            <Image src={preview || "/placeholder.svg"} alt="Preview" fill className="object-cover" />
          </div>

          <Button
            type="button"
            variant="destructive"
            size="icon"
            className="absolute top-2 right-2"
            onClick={handleRemove}
          >
            <X className="h-4 w-4" />
          </Button>
        </div>
      )}
    </div>
  )
}
