"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { Button } from "@/components/ui/button"

export default function TravelTips() {
  const [email, setEmail] = useState("")

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault()
    // Implementar lógica de inscrição na newsletter
    alert(`Email ${email} inscrito com sucesso!`)
    setEmail("")
  }

  return (
    <div className="py-8">
      <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
        <div className="bg-blue-50 p-6 rounded-lg">
          <h2 className="text-xl font-bold mb-4">Viaje mais, gaste menos</h2>
          <p className="mb-4">Dicas para economizar em sua próxima viagem:</p>
          <ul className="list-disc pl-5 mb-4 space-y-2">
            <li>Reserve com antecedência para melhores preços</li>
            <li>Viaje fora da alta temporada</li>
            <li>Procure por promoções e descontos exclusivos</li>
            <li>Use filtros de preço para encontrar opções econômicas</li>
          </ul>
          <Link href="/travel-tips">
            <Button className="bg-booking-blue">Mais dicas de viagem</Button>
          </Link>
        </div>

        <div className="bg-blue-600 text-white p-6 rounded-lg">
          <h2 className="text-xl font-bold mb-4">Quer as melhores ofertas de viagem?</h2>
          <p className="mb-4">Inscreva-se para receber ofertas exclusivas e dicas de viagem:</p>
          <form onSubmit={handleSubmit} className="space-y-4">
            <input
              type="email"
              placeholder="Seu endereço de e-mail"
              className="w-full p-3 rounded text-black"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
            />
            <Button type="submit" className="w-full bg-booking-yellow text-black hover:bg-yellow-400">
              Inscrever-se
            </Button>
          </form>
        </div>
      </div>
    </div>
  )
}
