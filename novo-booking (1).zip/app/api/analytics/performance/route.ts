import { NextResponse } from "next/server"
import prisma from "@/lib/prisma"

export async function POST(request: Request) {
  try {
    const { pageLoadTime, domReadyTime, url } = await request.json()

    if (!pageLoadTime || !url) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const userAgent = request.headers.get("user-agent") || null

    // Registrar métricas de performance
    await prisma.performanceMetric.create({
      data: {
        url,
        pageLoadTime,
        domReadyTime,
        userAgent,
        timestamp: new Date(),
      },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Erro ao registrar métricas de performance:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
