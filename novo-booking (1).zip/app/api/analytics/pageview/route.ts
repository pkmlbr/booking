import { NextResponse } from "next/server"
import prisma from "@/lib/prisma"
import { getCurrentUser } from "@/lib/auth"

export async function POST(request: Request) {
  try {
    const { path, referrer } = await request.json()

    if (!path) {
      return NextResponse.json({ error: "Path is required" }, { status: 400 })
    }

    const user = await getCurrentUser()
    const userId = user?.id

    const userAgent = request.headers.get("user-agent") || null
    const ip = request.headers.get("x-forwarded-for") || request.headers.get("x-real-ip") || "unknown"

    // Registrar visualização de página
    await prisma.pageView.create({
      data: {
        path,
        referrer,
        userAgent,
        ipAddress: ip.split(",")[0].trim(),
        userId,
      },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Erro ao registrar visualização de página:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
