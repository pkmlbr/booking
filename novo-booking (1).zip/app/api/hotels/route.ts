import { NextResponse } from "next/server"
import prisma from "@/lib/prisma"
import { getCurrentUser } from "@/lib/auth"

// GET - Buscar hotéis com filtros
export async function GET(request: Request) {
  try {
    const { searchParams } = new URL(request.url)

    const location = searchParams.get("location")
    const checkIn = searchParams.get("checkIn")
    const checkOut = searchParams.get("checkOut")
    const adults = Number.parseInt(searchParams.get("adults") || "1")
    const children = Number.parseInt(searchParams.get("children") || "0")
    const page = Number.parseInt(searchParams.get("page") || "1")
    const limit = Number.parseInt(searchParams.get("limit") || "10")
    const skip = (page - 1) * limit

    // Construir a query
    const where: any = {
      isActive: true,
    }

    // Filtrar por localização (cidade ou estado)
    if (location) {
      where.OR = [
        { city: { contains: location, mode: "insensitive" } },
        { state: { contains: location, mode: "insensitive" } },
        { name: { contains: location, mode: "insensitive" } },
      ]
    }

    // Buscar hotéis
    const [hotels, total] = await Promise.all([
      prisma.hotel.findMany({
        where,
        include: {
          images: {
            where: { isPrimary: true },
            take: 1,
          },
        },
        orderBy: {
          isFeatured: "desc",
        },
        skip,
        take: limit,
      }),
      prisma.hotel.count({ where }),
    ])

    return NextResponse.json({
      hotels,
      pagination: {
        total,
        page,
        limit,
        pages: Math.ceil(total / limit),
      },
    })
  } catch (error) {
    console.error("Erro ao buscar hotéis:", error)
    return NextResponse.json({ error: "Erro ao buscar hotéis" }, { status: 500 })
  }
}

// POST - Adicionar novo hotel
export async function POST(request: Request) {
  try {
    const user = await getCurrentUser()

    // Verificar permissões
    if (!user || !["SUPER_ADMIN", "ADMIN"].includes(user.role)) {
      return NextResponse.json({ error: "Não autorizado" }, { status: 401 })
    }

    const data = await request.json()

    // Validar dados obrigatórios
    if (!data.name || !data.address || !data.city || !data.state) {
      return NextResponse.json({ error: "Dados incompletos" }, { status: 400 })
    }

    // Criar hotel
    const hotel = await prisma.hotel.create({
      data: {
        name: data.name,
        description: data.description,
        shortDescription: data.shortDescription,
        address: data.address,
        city: data.city,
        state: data.state,
        country: data.country || "Brasil",
        postalCode: data.postalCode,
        latitude: data.latitude ? Number.parseFloat(data.latitude) : null,
        longitude: data.longitude ? Number.parseFloat(data.longitude) : null,
        phone: data.phone,
        email: data.email,
        website: data.website,
        checkInTime: data.checkInTime || "14:00",
        checkOutTime: data.checkOutTime || "12:00",
        starRating: data.starRating ? Number.parseFloat(data.starRating) : null,
        isActive: true,
        isFeatured: data.isFeatured || false,
        minPrice: data.minPrice ? Number.parseFloat(data.minPrice) : null,
        maxPrice: data.maxPrice ? Number.parseFloat(data.maxPrice) : null,
        images: {
          create:
            data.images?.map((image: any, index: number) => ({
              imageUrl: image.imageUrl,
              altText: image.altText || `Imagem ${index + 1} de ${data.name}`,
              isPrimary: index === 0, // Primeira imagem é a principal
              sortOrder: index,
            })) || [],
        },
      },
    })

    // Registrar atividade
    await prisma.activityLog.create({
      data: {
        action: "CREATE",
        entityType: "HOTEL",
        entityId: hotel.id,
        description: `Hotel "${hotel.name}" criado`,
        userId: user.id,
      },
    })

    return NextResponse.json({
      message: "Hotel criado com sucesso",
      hotel,
    })
  } catch (error) {
    console.error("Erro ao criar hotel:", error)
    return NextResponse.json({ error: "Erro ao criar hotel" }, { status: 500 })
  }
}
