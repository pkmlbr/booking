import { NextResponse } from "next/server"
import prisma from "@/lib/prisma"
import { getCurrentUser } from "@/lib/auth"

export async function POST(request: Request) {
  try {
    const { type, text, url } = await request.json()

    if (!type || !url) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const user = await getCurrentUser()
    const userId = user?.id

    // Registrar feedback
    await prisma.feedback.create({
      data: {
        type,
        text: text || null,
        url,
        userId,
        userAgent: request.headers.get("user-agent") || null,
      },
    })

    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Erro ao registrar feedback:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}
