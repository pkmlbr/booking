import { NextResponse } from "next/server"
import { optimizeImage } from "@/lib/image-optimizer"

export async function POST(request: Request) {
  try {
    const formData = await request.formData()
    const file = formData.get("image") as File

    if (!file) {
      return NextResponse.json({ error: "No image provided" }, { status: 400 })
    }

    const buffer = Buffer.from(await file.arrayBuffer())
    const width = Number.parseInt(formData.get("width") as string) || undefined
    const height = Number.parseInt(formData.get("height") as string) || undefined
    const quality = Number.parseInt(formData.get("quality") as string) || 80
    const format = (formData.get("format") as string) || "webp"

    const optimizedBuffer = await optimizeImage(buffer, {
      width,
      height,
      quality,
      format: format as "jpeg" | "png" | "webp" | "avif",
    })

    return new NextResponse(optimizedBuffer, {
      headers: {
        "Content-Type": `image/${format}`,
        "Cache-Control": "public, max-age=31536000, immutable",
      },
    })
  } catch (error) {
    console.error("Error optimizing image:", error)
    return NextResponse.json({ error: "Failed to optimize image" }, { status: 500 })
  }
}
