import { type NextRequest, NextResponse } from "next/server"
import { comparePasswords, setUserCookie } from "@/lib/auth"
import prisma from "@/lib/prisma"

export async function POST(request: NextRequest) {
  try {
    const { email, password } = await request.json()

    // Validar os dados de entrada
    if (!email || !password) {
      return NextResponse.json({ message: "Email e senha são obrigatórios" }, { status: 400 })
    }

    // Buscar o usuário pelo email
    const user = await prisma.user.findUnique({
      where: { email },
    })

    // Verificar se o usuário existe
    if (!user) {
      return NextResponse.json({ message: "Credenciais inválidas" }, { status: 401 })
    }

    // Verificar se o usuário está ativo
    if (!user.isActive) {
      return NextResponse.json({ message: "Conta desativada. Entre em contato com o administrador." }, { status: 403 })
    }

    // Verificar a senha
    const passwordMatch = await comparePasswords(password, user.password)
    if (!passwordMatch) {
      return NextResponse.json({ message: "Credenciais inválidas" }, { status: 401 })
    }

    // Atualizar informações de login
    await prisma.user.update({
      where: { id: user.id },
      data: {
        lastLogin: new Date(),
        loginCount: { increment: 1 },
      },
    })

    // Criar e definir o cookie JWT
    const userData = await setUserCookie(user.id)

    return NextResponse.json({
      message: "Login realizado com sucesso",
      user: userData,
    })
  } catch (error) {
    console.error("Erro ao fazer login:", error)
    return NextResponse.json({ message: "Erro interno do servidor" }, { status: 500 })
  }
}
