"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Switch } from "@/components/ui/switch"
import { Loader2, Plus, X } from "lucide-react"
import { useToast } from "@/hooks/use-toast"
import ImageUpload from "@/components/image-upload"

export default function AddHotelPage() {
  const router = useRouter()
  const { toast } = useToast()
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [hotel, setHotel] = useState({
    name: "",
    description: "",
    shortDescription: "",
    address: "",
    city: "",
    state: "",
    country: "Brasil",
    postalCode: "",
    phone: "",
    email: "",
    website: "",
    checkInTime: "14:00",
    checkOutTime: "12:00",
    starRating: "",
    isFeatured: false,
    minPrice: "",
    maxPrice: "",
    images: [] as { imageUrl: string; altText?: string }[],
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setHotel((prev) => ({ ...prev, [name]: value }))
  }

  const handleSwitchChange = (name: string, checked: boolean) => {
    setHotel((prev) => ({ ...prev, [name]: checked }))
  }

  const handleImageUpload = (url: string) => {
    setHotel((prev) => ({
      ...prev,
      images: [...prev.images, { imageUrl: url }],
    }))
  }

  const removeImage = (index: number) => {
    setHotel((prev) => ({
      ...prev,
      images: prev.images.filter((_, i) => i !== index),
    }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)

    try {
      // Validar campos obrigatórios
      if (!hotel.name || !hotel.address || !hotel.city || !hotel.state) {
        toast({
          title: "Campos obrigatórios",
          description: "Preencha todos os campos obrigatórios",
          variant: "destructive",
        })
        setIsSubmitting(false)
        return
      }

      // Enviar para a API
      const response = await fetch("/api/hotels", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify(hotel),
      })

      const data = await response.json()

      if (!response.ok) {
        throw new Error(data.error || "Erro ao adicionar hotel")
      }

      toast({
        title: "Hotel adicionado",
        description: "Hotel adicionado com sucesso",
      })

      // Redirecionar para a lista de hotéis
      router.push("/admin/hotels")
      router.refresh()
    } catch (error) {
      console.error("Erro ao adicionar hotel:", error)
      toast({
        title: "Erro",
        description: error instanceof Error ? error.message : "Erro ao adicionar hotel",
        variant: "destructive",
      })
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="container mx-auto py-8">
      <h1 className="text-2xl font-bold mb-6">Adicionar Novo Hotel</h1>

      <form onSubmit={handleSubmit}>
        <Tabs defaultValue="basic" className="w-full">
          <TabsList className="mb-4">
            <TabsTrigger value="basic">Informações Básicas</TabsTrigger>
            <TabsTrigger value="details">Detalhes</TabsTrigger>
            <TabsTrigger value="images">Imagens</TabsTrigger>
          </TabsList>

          <TabsContent value="basic">
            <Card>
              <CardHeader>
                <CardTitle>Informações Básicas</CardTitle>
                <CardDescription>Preencha as informações básicas do hotel</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Nome do Hotel *</Label>
                    <Input id="name" name="name" value={hotel.name} onChange={handleChange} required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="starRating">Classificação (estrelas)</Label>
                    <Input
                      id="starRating"
                      name="starRating"
                      type="number"
                      min="1"
                      max="5"
                      step="0.1"
                      value={hotel.starRating}
                      onChange={handleChange}
                    />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="shortDescription">Descrição Curta</Label>
                  <Input
                    id="shortDescription"
                    name="shortDescription"
                    value={hotel.shortDescription}
                    onChange={handleChange}
                    placeholder="Uma breve descrição do hotel"
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="description">Descrição Completa</Label>
                  <Textarea
                    id="description"
                    name="description"
                    value={hotel.description}
                    onChange={handleChange}
                    rows={5}
                  />
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="address">Endereço *</Label>
                    <Input id="address" name="address" value={hotel.address} onChange={handleChange} required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="postalCode">CEP</Label>
                    <Input id="postalCode" name="postalCode" value={hotel.postalCode} onChange={handleChange} />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="city">Cidade *</Label>
                    <Input id="city" name="city" value={hotel.city} onChange={handleChange} required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="state">Estado *</Label>
                    <Input id="state" name="state" value={hotel.state} onChange={handleChange} required />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="country">País</Label>
                    <Input id="country" name="country" value={hotel.country} onChange={handleChange} />
                  </div>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="details">
            <Card>
              <CardHeader>
                <CardTitle>Detalhes do Hotel</CardTitle>
                <CardDescription>Informações adicionais sobre o hotel</CardDescription>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="phone">Telefone</Label>
                    <Input id="phone" name="phone" value={hotel.phone} onChange={handleChange} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input id="email" name="email" type="email" value={hotel.email} onChange={handleChange} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="website">Website</Label>
                    <Input id="website" name="website" value={hotel.website} onChange={handleChange} />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="checkInTime">Horário de Check-in</Label>
                    <Input id="checkInTime" name="checkInTime" value={hotel.checkInTime} onChange={handleChange} />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="checkOutTime">Horário de Check-out</Label>
                    <Input id="checkOutTime" name="checkOutTime" value={hotel.checkOutTime} onChange={handleChange} />
                  </div>
                </div>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="minPrice">Preço Mínimo (R$)</Label>
                    <Input
                      id="minPrice"
                      name="minPrice"
                      type="number"
                      min="0"
                      step="0.01"
                      value={hotel.minPrice}
                      onChange={handleChange}
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="maxPrice">Preço Máximo (R$)</Label>
                    <Input
                      id="maxPrice"
                      name="maxPrice"
                      type="number"
                      min="0"
                      step="0.01"
                      value={hotel.maxPrice}
                      onChange={handleChange}
                    />
                  </div>
                </div>

                <div className="flex items-center space-x-2">
                  <Switch
                    id="isFeatured"
                    checked={hotel.isFeatured}
                    onCheckedChange={(checked) => handleSwitchChange("isFeatured", checked)}
                  />
                  <Label htmlFor="isFeatured">Destacar na página inicial</Label>
                </div>
              </CardContent>
            </Card>
          </TabsContent>

          <TabsContent value="images">
            <Card>
              <CardHeader>
                <CardTitle>Imagens do Hotel</CardTitle>
                <CardDescription>Adicione imagens do hotel (a primeira será a principal)</CardDescription>
              </CardHeader>
              <CardContent>
                <div className="mb-4">
                  <ImageUpload onUpload={handleImageUpload} />
                </div>

                {hotel.images.length > 0 && (
                  <div className="grid grid-cols-2 md:grid-cols-3 lg:grid-cols-4 gap-4 mt-6">
                    {hotel.images.map((image, index) => (
                      <div key={index} className="relative group">
                        <img
                          src={image.imageUrl || "/placeholder.svg"}
                          alt={`Imagem ${index + 1}`}
                          className="w-full h-40 object-cover rounded-md"
                        />
                        <Button
                          type="button"
                          variant="destructive"
                          size="icon"
                          className="absolute top-2 right-2 opacity-0 group-hover:opacity-100 transition-opacity"
                          onClick={() => removeImage(index)}
                        >
                          <X className="h-4 w-4" />
                        </Button>
                        {index === 0 && (
                          <span className="absolute bottom-2 left-2 bg-primary text-white text-xs px-2 py-1 rounded">
                            Principal
                          </span>
                        )}
                      </div>
                    ))}
                  </div>
                )}
              </CardContent>
            </Card>
          </TabsContent>

          <CardFooter className="flex justify-between mt-6">
            <Button type="button" variant="outline" onClick={() => router.back()} disabled={isSubmitting}>
              Cancelar
            </Button>
            <Button type="submit" disabled={isSubmitting}>
              {isSubmitting ? (
                <>
                  <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                  Salvando...
                </>
              ) : (
                <>
                  <Plus className="mr-2 h-4 w-4" />
                  Adicionar Hotel
                </>
              )}
            </Button>
          </CardFooter>
        </Tabs>
      </form>
    </div>
  )
}
