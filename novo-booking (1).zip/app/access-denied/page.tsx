import Link from "next/link"
import Header from "@/components/header"
import Footer from "@/components/footer"
import { Button } from "@/components/ui/button"
import { ShieldAlert } from "lucide-react"

export default function AccessDeniedPage() {
  return (
    <div className="min-h-screen flex flex-col">
      <Header />

      <main className="flex-grow flex items-center justify-center py-12 px-4 sm:px-6 lg:px-8 bg-gray-50 dark:bg-gray-900">
        <div className="max-w-md w-full text-center">
          <div className="flex justify-center mb-6">
            <ShieldAlert className="h-24 w-24 text-destructive" />
          </div>
          <h1 className="text-3xl font-bold mb-4">Acesso Negado</h1>
          <p className="text-lg mb-8">
            Você não tem permissão para acessar esta página. Por favor, entre em contato com o administrador se acredita
            que isso é um erro.
          </p>
          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Link href="/">
              <Button>Voltar para a página inicial</Button>
            </Link>
            <Link href="/login">
              <Button variant="outline">Fazer login com outra conta</Button>
            </Link>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  )
}
