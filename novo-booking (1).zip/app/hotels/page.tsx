"use client"

import { useEffect, useState } from "react"
import { useSearchParams } from "next/navigation"

// Desktop components
import BookingHeader from "@/components/booking-header"
import BookingSearchBar from "@/components/booking-search-bar"
import HotelList from "@/components/hotel-list"
import BookingFooter from "@/components/booking-footer"
import HotelFilters from "@/components/hotel-filters"

// Mobile components
import BookingMobileHeader from "@/components/booking-mobile-header"
import BookingMobileSearch from "@/components/booking-mobile-search"
import MobileHotelList from "@/components/mobile-hotel-list"
import MobileHotelFilters from "@/components/mobile-hotel-filters"
import MobileFooter from "@/components/mobile-footer"
import MobileNavigation from "@/components/mobile-navigation"

export default function HotelsPage() {
  const [isMobile, setIsMobile] = useState(false)
  const searchParams = useSearchParams()

  const location = searchParams.get("location") || undefined
  const checkIn = searchParams.get("checkIn") || undefined
  const checkOut = searchParams.get("checkOut") || undefined
  const adults = searchParams.get("adults") ? Number(searchParams.get("adults")) : undefined
  const children = searchParams.get("children") ? Number(searchParams.get("children")) : undefined
  const rooms = searchParams.get("rooms") ? Number(searchParams.get("rooms")) : undefined
  const page = searchParams.get("page") ? Number(searchParams.get("page")) : 1

  useEffect(() => {
    const checkIfMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }

    // Initial check
    checkIfMobile()

    // Add event listener for window resize
    window.addEventListener("resize", checkIfMobile)

    // Clean up
    return () => {
      window.removeEventListener("resize", checkIfMobile)
    }
  }, [])

  if (isMobile) {
    return (
      <div className="min-h-screen flex flex-col pb-16">
        <BookingMobileHeader />

        <main className="flex-grow">
          <BookingMobileSearch
            initialLocation={location}
            initialCheckIn={checkIn ? new Date(checkIn) : undefined}
            initialCheckOut={checkOut ? new Date(checkOut) : undefined}
            initialAdults={adults}
            initialChildren={children}
            initialRooms={rooms}
          />

          <MobileHotelFilters location={location} checkIn={checkIn} checkOut={checkOut} />

          <MobileHotelList
            location={location}
            checkIn={checkIn}
            checkOut={checkOut}
            adults={adults}
            children={children}
            page={page}
          />
        </main>

        <MobileFooter />
        <MobileNavigation />
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <BookingHeader />

      <main className="flex-grow">
        <div className="bg-booking-blue py-4">
          <div className="booking-container">
            <BookingSearchBar
              variant="hotels"
              initialLocation={location}
              initialCheckIn={checkIn ? new Date(checkIn) : undefined}
              initialCheckOut={checkOut ? new Date(checkOut) : undefined}
              initialAdults={adults}
              initialChildren={children}
              initialRooms={rooms}
            />
          </div>
        </div>

        <div className="booking-container py-6">
          <div className="grid grid-cols-1 lg:grid-cols-4 gap-6">
            <div className="lg:col-span-1">
              <HotelFilters location={location} checkIn={checkIn} checkOut={checkOut} />
            </div>

            <div className="lg:col-span-3">
              <HotelList
                location={location}
                checkIn={checkIn}
                checkOut={checkOut}
                adults={adults}
                children={children}
                page={page}
              />
            </div>
          </div>
        </div>
      </main>

      <BookingFooter />
    </div>
  )
}
