import type React from "react"
import "./globals.css"
import { AuthProvider } from "@/contexts/auth-context"
import { ThemeProvider } from "@/components/theme-provider"
import Script from "next/script"
import { inter, robotoMono } from "@/lib/font-optimization"
import Analytics from "@/components/analytics"
import PerformanceMonitor from "@/components/performance-monitor"
import { Toaster } from "@/components/ui/toast"
import { Suspense } from "react"

export const metadata = {
  title: "Novo Booking - Reservas de Hotéis, Casas e muito mais",
  description: "Preços baixos em hotéis, casas e apartamentos em todo o Brasil e no mundo",
  manifest: "/manifest.json",
  themeColor: "#003580",
  viewport: "width=device-width, initial-scale=1, maximum-scale=5",
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="pt-BR" suppressHydrationWarning className={`${inter.variable} ${robotoMono.variable}`}>
      <head>
        <link rel="apple-touch-icon" href="/icons/icon-192x192.png" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="dns-prefetch" href="https://fonts.googleapis.com" />
      </head>
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem={false}>
          <AuthProvider>
            <Suspense fallback={<div className="h-screen w-full flex items-center justify-center">Carregando...</div>}>
              {children}
              <Toaster />
            </Suspense>
          </AuthProvider>
        </ThemeProvider>
        <Analytics />
        <PerformanceMonitor />
        <Script id="register-sw" strategy="afterInteractive">
          {`
            if ('serviceWorker' in navigator && window.location.hostname !== 'localhost') {
              window.addEventListener('load', function() {
                navigator.serviceWorker.register('/sw.js').then(
                  function(registration) {
                    console.log('ServiceWorker registration successful with scope: ', registration.scope);
                  },
                  function(err) {
                    console.log('ServiceWorker registration failed: ', err);
                  }
                );
              });
            }
          `}
        </Script>
      </body>
    </html>
  )
}
