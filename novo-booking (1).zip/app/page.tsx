"use client"

import { useEffect, useState } from "react"

// Desktop components
import BookingHeader from "@/components/booking-header"
import BookingSearchBar from "@/components/booking-search-bar"
import BookingOffers from "@/components/booking-offers"
import PopularDestinations from "@/components/popular-destinations"
import AccommodationTypes from "@/components/accommodation-types"
import FeaturedProperties from "@/components/featured-properties"
import BookingFooter from "@/components/booking-footer"
import RecentSearches from "@/components/recent-searches"
import TravelTips from "@/components/travel-tips"
import ExploreRegions from "@/components/explore-regions"

// Mobile components
import BookingMobileHeader from "@/components/booking-mobile-header"
import BookingMobileSearch from "@/components/booking-mobile-search"
import MobileRecentSearches from "@/components/mobile-recent-searches"
import MobileOffers from "@/components/mobile-offers"
import MobileAccommodationTypes from "@/components/mobile-accommodation-types"
import MobileDestinations from "@/components/mobile-destinations"
import MobileTripPlanning from "@/components/mobile-trip-planning"
import MobileWeekendDeals from "@/components/mobile-weekend-deals"
import MobileExclusiveAccommodations from "@/components/mobile-exclusive-accommodations"
import MobileTravelTips from "@/components/mobile-travel-tips"
import MobilePopularDestinations from "@/components/mobile-popular-destinations"
import MobileFooter from "@/components/mobile-footer"
import MobileNavigation from "@/components/mobile-navigation"

export default function Home() {
  const [isMobile, setIsMobile] = useState(false)

  useEffect(() => {
    const checkIfMobile = () => {
      setIsMobile(window.innerWidth < 768)
    }

    // Initial check
    checkIfMobile()

    // Add event listener for window resize
    window.addEventListener("resize", checkIfMobile)

    // Clean up
    return () => {
      window.removeEventListener("resize", checkIfMobile)
    }
  }, [])

  if (isMobile) {
    return (
      <div className="min-h-screen flex flex-col pb-16">
        <BookingMobileHeader />

        <main className="flex-grow">
          <BookingMobileSearch />
          <MobileRecentSearches />
          <MobileOffers />
          <MobileAccommodationTypes />
          <MobileDestinations />
          <MobileTripPlanning />
          <MobileWeekendDeals />
          <MobileExclusiveAccommodations />
          <MobileTravelTips />
          <MobilePopularDestinations />
        </main>

        <MobileFooter />
        <MobileNavigation />
      </div>
    )
  }

  return (
    <div className="min-h-screen flex flex-col">
      <BookingHeader />

      <main className="flex-grow">
        {/* Hero Section */}
        <section className="bg-booking-blue py-6">
          <div className="booking-container">
            <div className="text-white mb-6">
              <h1 className="text-3xl font-bold mb-2">Encontre sua próxima estadia</h1>
              <p className="text-lg">Encontre ofertas em hotéis, casas, apartamentos e muito mais...</p>
            </div>

            <BookingSearchBar variant="home" />
          </div>
        </section>

        <div className="booking-container">
          {/* Recent Searches */}
          <RecentSearches />

          {/* Offers */}
          <BookingOffers />

          {/* Popular Destinations */}
          <PopularDestinations />

          {/* Accommodation Types */}
          <AccommodationTypes />

          {/* Featured Properties */}
          <FeaturedProperties />

          {/* Explore Brazil Regions */}
          <ExploreRegions />

          {/* Travel Tips */}
          <TravelTips />
        </div>
      </main>

      <BookingFooter />
    </div>
  )
}
