import Link from "next/link"
import { Button } from "@/components/ui/button"
import { WifiOff } from "lucide-react"

export default function OfflinePage() {
  return (
    <div className="min-h-screen flex flex-col items-center justify-center p-4">
      <WifiOff className="h-24 w-24 text-gray-400 mb-6" />
      <h1 className="text-3xl font-bold mb-4">Você está offline</h1>
      <p className="text-lg text-center mb-8 max-w-md">
        Parece que você está sem conexão com a internet. Algumas funcionalidades podem não estar disponíveis.
      </p>
      <Link href="/">
        <Button>Tentar novamente</Button>
      </Link>
    </div>
  )
}
