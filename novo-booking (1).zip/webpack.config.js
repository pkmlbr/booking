module.exports = {
  webpack: (config, { dev, isServer }) => {
    // Otimizações apenas para produção
    if (!dev) {
      // Dividir chunks para melhor caching
      config.optimization.splitChunks = {
        chunks: "all",
        maxInitialRequests: Number.POSITIVE_INFINITY,
        minSize: 20000,
        cacheGroups: {
          vendor: {
            test: /[\\/]node_modules[\\/]/,
            name(module) {
              // Obter o nome do pacote npm
              const packageName = module.context.match(/[\\/]node_modules[\\/](.*?)([\\/]|$)/)[1]

              // Criar um nome de chunk válido
              return `npm.${packageName.replace("@", "")}`
            },
          },
        },
      }

      // Comprimir melhor
      config.optimization.minimize = true
    }

    // Otimizações para o servidor
    if (isServer) {
      // Ignorar pacotes que são apenas para o cliente
      const originalEntry = config.entry
      config.entry = async () => {
        const entries = await originalEntry()
        return entries
      }
    }

    return config
  },
}
