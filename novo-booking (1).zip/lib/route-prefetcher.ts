"use client"

import { useEffect } from "react"
import { usePathname } from "next/navigation"
import { useRouter } from "next/router"

export function usePrefetchRoutes(routes: string[]) {
  const router = useRouter()
  const pathname = usePathname()

  useEffect(() => {
    // Não pré-carregar a rota atual
    const routesToPrefetch = routes.filter((route) => route !== pathname)

    // Pré-carregar rotas em segundo plano
    routesToPrefetch.forEach((route) => {
      router.prefetch(route)
    })
  }, [pathname, routes, router])
}
