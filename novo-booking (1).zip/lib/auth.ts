import { SignJWT, jwtVerify } from "jose"
import { cookies } from "next/headers"
import type { NextRequest } from "next/server"
import bcrypt from "bcryptjs"
import prisma from "@/lib/prisma"

const JWT_SECRET = process.env.JWT_SECRET || "seu-segredo-jwt-super-seguro"

export async function hashPassword(password: string): Promise<string> {
  return bcrypt.hash(password, 10)
}

export async function comparePasswords(password: string, hashedPassword: string): Promise<boolean> {
  return bcrypt.compare(password, hashedPassword)
}

export async function createJwtToken(payload: any): Promise<string> {
  const iat = Math.floor(Date.now() / 1000)
  const exp = iat + 60 * 60 * 24 * 7 // 7 dias

  return new SignJWT({ ...payload })
    .setProtectedHeader({ alg: "HS256", typ: "JWT" })
    .setExpirationTime(exp)
    .setIssuedAt(iat)
    .setNotBefore(iat)
    .sign(new TextEncoder().encode(JWT_SECRET))
}

export async function verifyJwtToken(token: string) {
  try {
    const verified = await jwtVerify(token, new TextEncoder().encode(JWT_SECRET))
    return verified.payload
  } catch (error) {
    throw new Error("Token inválido ou expirado")
  }
}

export async function getUserFromToken(request: NextRequest) {
  const token = request.cookies.get("token")?.value

  if (!token) {
    return null
  }

  try {
    const verified = await verifyJwtToken(token)
    return verified
  } catch (error) {
    return null
  }
}

export async function setUserCookie(userId: string) {
  const user = await prisma.user.findUnique({
    where: { id: userId },
    select: {
      id: true,
      name: true,
      email: true,
      role: true,
    },
  })

  if (!user) {
    throw new Error("Usuário não encontrado")
  }

  const token = await createJwtToken(user)

  cookies().set({
    name: "token",
    value: token,
    httpOnly: true,
    path: "/",
    secure: process.env.NODE_ENV === "production",
    maxAge: 60 * 60 * 24 * 7, // 7 dias
  })

  return user
}

export async function removeUserCookie() {
  cookies().set({
    name: "token",
    value: "",
    httpOnly: true,
    path: "/",
    secure: process.env.NODE_ENV === "production",
    maxAge: 0,
  })
}

export async function getCurrentUser() {
  const token = cookies().get("token")?.value

  if (!token) {
    return null
  }

  try {
    const payload = await verifyJwtToken(token)

    // Verificar se o usuário ainda existe e está ativo
    const user = await prisma.user.findUnique({
      where: {
        id: payload.id as string,
        isActive: true,
      },
      select: {
        id: true,
        name: true,
        email: true,
        role: true,
      },
    })

    if (!user) {
      // Se o usuário não existir mais ou estiver inativo, remover o cookie
      removeUserCookie()
      return null
    }

    return user
  } catch (error) {
    // Token inválido ou expirado
    removeUserCookie()
    return null
  }
}
