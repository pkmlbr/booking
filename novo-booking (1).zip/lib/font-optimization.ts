import { Inter, Roboto_Mono } from "next/font/google"

export const inter = Inter({
  subsets: ["latin"],
  display: "swap",
  preload: true,
  fallback: ["system-ui", "sans-serif"],
  adjustFontFallback: true,
  variable: "--font-inter",
})

export const robotoMono = Roboto_Mono({
  subsets: ["latin"],
  display: "swap",
  preload: true,
  fallback: ["monospace"],
  variable: "--font-roboto-mono",
})
