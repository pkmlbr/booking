type RequestMethod = "GET" | "POST" | "PUT" | "DELETE" | "PATCH"

interface RequestOptions {
  method?: RequestMethod
  body?: any
  headers?: Record<string, string>
  cache?: RequestCache
  next?: {
    revalidate?: number | false
    tags?: string[]
  }
}

interface ApiResponse<T> {
  data: T | null
  error: string | null
  status: number
}

const BASE_URL = process.env.NEXT_PUBLIC_API_URL || ""

export async function apiClient<T = any>(endpoint: string, options: RequestOptions = {}): Promise<ApiResponse<T>> {
  const { method = "GET", body, headers = {}, cache, next } = options

  const url = endpoint.startsWith("http") ? endpoint : `${BASE_URL}${endpoint}`

  const requestHeaders: HeadersInit = {
    "Content-Type": "application/json",
    ...headers,
  }

  const requestOptions: RequestInit = {
    method,
    headers: requestHeaders,
    cache,
    next,
  }

  if (body) {
    requestOptions.body = JSON.stringify(body)
  }

  try {
    const response = await fetch(url, requestOptions)

    let data = null

    // Tentar parsear o corpo da resposta como JSON
    try {
      data = await response.json()
    } catch (e) {
      // Se não for JSON, pode ser texto ou vazio
      if (response.status !== 204) {
        // No Content
        data = (await response.text()) || null
      }
    }

    if (!response.ok) {
      return {
        data: null,
        error: data?.message || `Erro ${response.status}: ${response.statusText}`,
        status: response.status,
      }
    }

    return {
      data,
      error: null,
      status: response.status,
    }
  } catch (error) {
    return {
      data: null,
      error: error instanceof Error ? error.message : "Erro desconhecido",
      status: 0, // Código de status 0 indica erro de rede
    }
  }
}
