import sharp from "sharp"

export async function optimizeImage(
  buffer: Buffer,
  options: {
    width?: number
    height?: number
    quality?: number
    format?: "jpeg" | "png" | "webp" | "avif"
  } = {},
) {
  const { width, height, quality = 80, format = "webp" } = options

  let image = sharp(buffer)

  // Redimensionar se necessário
  if (width || height) {
    image = image.resize({
      width,
      height,
      fit: "inside",
      withoutEnlargement: true,
    })
  }

  // Converter para o formato desejado
  switch (format) {
    case "jpeg":
      image = image.jpeg({ quality })
      break
    case "png":
      image = image.png({ quality })
      break
    case "webp":
      image = image.webp({ quality })
      break
    case "avif":
      image = image.avif({ quality })
      break
  }

  return image.toBuffer()
}
