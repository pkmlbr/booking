type CacheItem<T> = {
  value: T
  expiry: number
}

class Cache {
  private cache: Map<string, CacheItem<any>> = new Map()

  set<T>(key: string, value: T, ttl: number = 60 * 1000) {
    const expiry = Date.now() + ttl
    this.cache.set(key, { value, expiry })
    return value
  }

  get<T>(key: string): T | null {
    const item = this.cache.get(key)

    if (!item) {
      return null
    }

    if (Date.now() > item.expiry) {
      this.cache.delete(key)
      return null
    }

    return item.value
  }

  has(key: string): boolean {
    const item = this.cache.get(key)

    if (!item) {
      return false
    }

    if (Date.now() > item.expiry) {
      this.cache.delete(key)
      return false
    }

    return true
  }

  delete(key: string): boolean {
    return this.cache.delete(key)
  }

  clear(): void {
    this.cache.clear()
  }
}

export const cache = new Cache()
