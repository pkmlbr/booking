import type { ImageLoaderProps } from "next/image"

export default function imageLoader({ src, width, quality }: ImageLoaderProps) {
  // Verificar se a imagem já é uma URL externa
  if (src.startsWith("http")) {
    // Para imagens externas, usar um serviço de otimização como Imgix, Cloudinary, etc.
    return `https://img.novobooking.com/image?url=${encodeURIComponent(src)}&w=${width}&q=${quality || 75}`
  }

  // Para imagens locais, usar a API de otimização interna
  return `${process.env.NEXT_PUBLIC_SITE_URL || ""}/api/optimize-image?url=${encodeURIComponent(src)}&w=${width}&q=${quality || 75}`
}
