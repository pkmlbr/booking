import { cache } from "react"

interface GenerateStaticParamsOptions<T> {
  fetch: () => Promise<T[]>
  getPath: (item: T) => { [key: string]: string }
}

export function generateStaticParams<T>({ fetch, getPath }: GenerateStaticParamsOptions<T>) {
  return cache(async () => {
    const items = await fetch()
    return items.map(getPath)
  })
}
