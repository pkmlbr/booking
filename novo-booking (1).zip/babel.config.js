module.exports = {
  presets: ["next/babel"],
  plugins: [
    ["transform-remove-console", { exclude: ["error", "warn"] }],
    process.env.NODE_ENV === "production" && [
      "transform-react-remove-prop-types",
      {
        removeImport: true,
        ignoreFilenames: ["node_modules"],
      },
    ],
  ].filter(Boolean),
}
