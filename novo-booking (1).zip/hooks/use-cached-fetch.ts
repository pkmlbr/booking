"use client"

import { useState, useEffect } from "react"
import { cache } from "@/lib/cache"

interface UseCachedFetchOptions {
  ttl?: number
  revalidateOnFocus?: boolean
  revalidateOnReconnect?: boolean
  dedupingInterval?: number
}

export function useCachedFetch<T>(url: string, options: UseCachedFetchOptions = {}) {
  const {
    ttl = 5 * 60 * 1000, // 5 minutos
    revalidateOnFocus = true,
    revalidateOnReconnect = true,
    dedupingInterval = 2000,
  } = options

  const [data, setData] = useState<T | null>(null)
  const [error, setError] = useState<Error | null>(null)
  const [isLoading, setIsLoading] = useState(true)
  const [lastFetchTime, setLastFetchTime] = useState(0)

  const fetchData = async () => {
    // Verificar intervalo de deduplição
    const now = Date.now()
    if (now - lastFetchTime < dedupingInterval) {
      return
    }

    setLastFetchTime(now)

    try {
      // Verificar cache
      const cacheKey = `fetch:${url}`
      const cachedData = cache.get<T>(cacheKey)

      if (cachedData) {
        setData(cachedData)
        setIsLoading(false)
        return
      }

      // Buscar dados
      const response = await fetch(url)

      if (!response.ok) {
        throw new Error(`Erro na requisição: ${response.status}`)
      }

      const result = await response.json()

      // Armazenar no cache
      cache.set(cacheKey, result, ttl)

      setData(result)
      setError(null)
    } catch (err) {
      setError(err instanceof Error ? err : new Error(String(err)))
    } finally {
      setIsLoading(false)
    }
  }

  useEffect(() => {
    fetchData()
  }, [url])

  useEffect(() => {
    if (!revalidateOnFocus) return

    const onFocus = () => {
      fetchData()
    }

    window.addEventListener("focus", onFocus)

    return () => {
      window.removeEventListener("focus", onFocus)
    }
  }, [revalidateOnFocus])

  useEffect(() => {
    if (!revalidateOnReconnect) return

    const onOnline = () => {
      fetchData()
    }

    window.addEventListener("online", onOnline)

    return () => {
      window.removeEventListener("online", onOnline)
    }
  }, [revalidateOnReconnect])

  return { data, error, isLoading, mutate: fetchData }
}
