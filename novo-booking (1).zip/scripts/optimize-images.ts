import fs from "fs"
import path from "path"
import sharp from "sharp"

const PUBLIC_DIR = path.join(process.cwd(), "public")
const OUTPUT_DIR = path.join(process.cwd(), "public/optimized")

// Garantir que o diretório de saída exista
if (!fs.existsSync(OUTPUT_DIR)) {
  fs.mkdirSync(OUTPUT_DIR, { recursive: true })
}

// Formatos de imagem suportados
const IMAGE_EXTENSIONS = [".jpg", ".jpeg", ".png", ".webp", ".gif"]

// Configurações de otimização
const SIZES = [640, 750, 828, 1080, 1200, 1920]
const FORMATS = ["webp", "avif"] as const

async function optimizeImage(filePath: string) {
  const fileName = path.basename(filePath)
  const fileExt = path.extname(filePath).toLowerCase()
  const baseName = path.basename(filePath, fileExt)

  if (!IMAGE_EXTENSIONS.includes(fileExt)) {
    console.log(`Pulando arquivo não suportado: ${fileName}`)
    return
  }

  console.log(`Otimizando: ${fileName}`)

  try {
    const image = sharp(filePath)
    const metadata = await image.metadata()

    // Processar cada tamanho e formato
    for (const size of SIZES) {
      // Pular tamanhos maiores que a imagem original
      if (metadata.width && size > metadata.width) continue

      for (const format of FORMATS) {
        const outputFileName = `${baseName}-${size}.${format}`
        const outputPath = path.join(OUTPUT_DIR, outputFileName)

        await image.resize(size)[format]({ quality: 80 }).toFile(outputPath)

        console.log(`  Criado: ${outputFileName}`)
      }
    }

    // Criar versão original otimizada em WebP
    const originalWebP = `${baseName}.webp`
    await image.webp({ quality: 85 }).toFile(path.join(OUTPUT_DIR, originalWebP))

    console.log(`  Criado: ${originalWebP}`)
  } catch (error) {
    console.error(`  Erro ao otimizar ${fileName}:`, error)
  }
}

async function processDirectory(directory: string) {
  const files = fs.readdirSync(directory)

  for (const file of files) {
    const filePath = path.join(directory, file)
    const stat = fs.statSync(filePath)

    if (stat.isDirectory()) {
      // Criar diretório correspondente na pasta de saída
      const relativePath = path.relative(PUBLIC_DIR, filePath)
      const outputSubDir = path.join(OUTPUT_DIR, relativePath)

      if (!fs.existsSync(outputSubDir)) {
        fs.mkdirSync(outputSubDir, { recursive: true })
      }

      // Processar subdiretório
      await processDirectory(filePath)
    } else if (stat.isFile()) {
      await optimizeImage(filePath)
    }
  }
}

async function main() {
  console.log("Iniciando otimização de imagens...")
  await processDirectory(PUBLIC_DIR)
  console.log("Otimização concluída!")
}

main().catch(console.error)
