import { hashPassword } from "../lib/auth"
import prisma from "../lib/prisma"

async function updateAdminPassword() {
  try {
    // Defina a nova senha aqui
    const newPassword = "admin123"

    // Hash da nova senha
    const hashedPassword = await hashPassword(newPassword)

    // Atualizar a senha do usuário admin
    const updatedUser = await prisma.user.update({
      where: {
        email: "admin@novobooking.com",
      },
      data: {
        password: hashedPassword,
      },
    })

    console.log("Senha do administrador atualizada com sucesso!")
    console.log("Email:", updatedUser.email)
    console.log("Nova senha:", newPassword)
  } catch (error) {
    console.error("Erro ao atualizar senha do administrador:", error)
  } finally {
    await prisma.$disconnect()
  }
}

updateAdminPassword()
