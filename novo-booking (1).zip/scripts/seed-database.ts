import { hashPassword } from "../lib/auth"
import prisma from "../lib/prisma"

async function seedDatabase() {
  try {
    console.log("Iniciando seed do banco de dados...")

    // Criar usuário administrador
    const adminPassword = await hashPassword("admin123")
    const admin = await prisma.user.upsert({
      where: { email: "admin@novobooking.com" },
      update: {},
      create: {
        name: "Administrador",
        email: "admin@novobooking.com",
        password: adminPassword,
        role: "SUPER_ADMIN",
      },
    })
    console.log("Usuário administrador criado:", admin.email)

    // Criar comodidades
    const amenities = await Promise.all([
      prisma.amenity.upsert({
        where: { id: "1" },
        update: {},
        create: {
          id: "1",
          name: "Wi-Fi",
          icon: "wifi",
          type: "both",
        },
      }),
      prisma.amenity.upsert({
        where: { id: "2" },
        update: {},
        create: {
          id: "2",
          name: "Ar-condicionado",
          icon: "air-conditioning",
          type: "both",
        },
      }),
      prisma.amenity.upsert({
        where: { id: "3" },
        update: {},
        create: {
          id: "3",
          name: "TV",
          icon: "tv",
          type: "room",
        },
      }),
      prisma.amenity.upsert({
        where: { id: "4" },
        update: {},
        create: {
          id: "4",
          name: "Piscina",
          icon: "pool",
          type: "hotel",
        },
      }),
      prisma.amenity.upsert({
        where: { id: "5" },
        update: {},
        create: {
          id: "5",
          name: "Academia",
          icon: "gym",
          type: "hotel",
        },
      }),
    ])
    console.log("Comodidades criadas:", amenities.length)

    // Criar hotéis
    const hotel1 = await prisma.hotel.upsert({
      where: { id: "1" },
      update: {},
      create: {
        id: "1",
        name: "Grand Hotel Rio",
        description: "Um luxuoso hotel à beira-mar com vista para a praia de Copacabana.",
        shortDescription: "Luxo à beira-mar em Copacabana",
        address: "Av. Atlântica, 1500",
        city: "Rio de Janeiro",
        state: "RJ",
        postalCode: "22021-001",
        latitude: -22.9671,
        longitude: -43.1769,
        phone: "(21) 3333-4444",
        email: "reservas@grandhotelrio.com",
        website: "www.grandhotelrio.com",
        starRating: 4.5,
        isActive: true,
        isFeatured: true,
        minPrice: 450,
        maxPrice: 1200,
        totalRooms: 120,
        images: {
          create: [
            {
              imageUrl: "/beach-resort-rio.png",
              altText: "Vista da praia de Copacabana",
              isPrimary: true,
              sortOrder: 1,
            },
            {
              imageUrl: "/luxury-hotel-room.png",
              altText: "Quarto luxuoso com vista para o mar",
              isPrimary: false,
              sortOrder: 2,
            },
            {
              imageUrl: "/hotel-swimming-pool.png",
              altText: "Piscina com vista para o mar",
              isPrimary: false,
              sortOrder: 3,
            },
          ],
        },
        amenities: {
          create: [{ amenityId: "1" }, { amenityId: "2" }, { amenityId: "4" }, { amenityId: "5" }],
        },
      },
    })

    // Criar tipos de quarto para o hotel
    const roomType1 = await prisma.roomType.create({
      data: {
        hotelId: hotel1.id,
        name: "Quarto Luxo Vista Mar",
        description: "Quarto espaçoso com vista panorâmica para o mar de Copacabana.",
        basePrice: 450,
        maxOccupancy: 3,
        maxAdults: 2,
        maxChildren: 1,
        sizeSqm: 35,
        bedType: "King",
        isActive: true,
        isFeatured: true,
        quantityAvailable: 20,
        images: {
          create: [
            {
              imageUrl: "/luxury-hotel-room.png",
              altText: "Quarto luxuoso com vista para o mar",
              isPrimary: true,
              sortOrder: 1,
            },
          ],
        },
        amenities: {
          create: [{ amenityId: "1" }, { amenityId: "2" }, { amenityId: "3" }],
        },
      },
    })

    // Criar quartos para o tipo de quarto
    for (let i = 1; i <= 20; i++) {
      await prisma.room.create({
        data: {
          roomTypeId: roomType1.id,
          roomNumber: `${i < 10 ? "0" : ""}${i}`,
          floor: "2",
          status: "available",
        },
      })
    }

    console.log("Hotel criado com sucesso:", hotel1.name)
    console.log("Tipo de quarto criado:", roomType1.name)
    console.log("20 quartos criados para o tipo de quarto")

    // Criar cliente de exemplo
    const customerPassword = await hashPassword("cliente123")
    const customer = await prisma.customer.upsert({
      where: { email: "cliente@exemplo.com" },
      update: {},
      create: {
        name: "Cliente Exemplo",
        email: "cliente@exemplo.com",
        password: customerPassword,
        phone: "(11) 98765-4321",
        cpf: "123.456.789-00",
        birthDate: new Date("1990-01-01"),
        address: "Rua Exemplo, 123",
        city: "São Paulo",
        state: "SP",
        postalCode: "01234-567",
        acceptMarketing: true,
      },
    })
    console.log("Cliente criado:", customer.email)

    console.log("Seed concluído com sucesso!")
  } catch (error) {
    console.error("Erro durante o seed:", error)
  } finally {
    await prisma.$disconnect()
  }
}

seedDatabase()
