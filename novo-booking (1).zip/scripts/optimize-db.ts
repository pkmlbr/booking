import { optimizeDatabase } from "../lib/db-optimizer"

async function main() {
  console.log("Starting database optimization...")

  const result = await optimizeDatabase()

  if (result.success) {
    console.log("✅ " + result.message)
  } else {
    console.error("❌ " + result.message)
    process.exit(1)
  }

  process.exit(0)
}

main()
